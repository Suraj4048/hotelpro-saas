import { v4 as uuidv4 } from 'uuid';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import FEATURES from '../config/features.js';

export class AuthService {
  constructor(models, emailService, smsService) {
    this.User = models.User;
    this.Organization = models.Organization;
    this.Role = models.Role;
    this.OTP = models.OTP;
    this.emailService = emailService;
    this.smsService = smsService;
  }

  // ===== OTP GENERATION =====
  async generateOTP(identifier, type) {
    const otp = Math.floor(100000 + Math.random() * 900000).toString();

    // DEMO MODE - Mock OTP
    if (FEATURES.MOCK_OTP) {
      console.log(`\n🔐 [DEMO MODE] OTP: ${otp}\n`);

      const otpRecord = await this.OTP.create({
        id: uuidv4(),
        identifier: identifier,
        type: type,
        otp: otp,
        expiresAt: new Date(Date.now() + 10 * 60 * 1000),
        attempts: 0,
        isUsed: false
      });

      return {
        success: true,
        otp: otp,
        message: `[DEMO] OTP: ${otp} - Check console above!`,
        expiresIn: 600,
        devMode: true
      };
    }

    // PRODUCTION - Real OTP
    const otpRecord = await this.OTP.create({
      id: uuidv4(),
      identifier: identifier,
      type: type,
      otp: otp,
      expiresAt: new Date(Date.now() + 10 * 60 * 1000),
      attempts: 0,
      isUsed: false
    });

    // Send via email
    if (type.includes('email') && FEATURES.SEND_REAL_EMAILS) {
      try {
        await this.emailService.sendOTP(identifier, otp, type);
      } catch (error) {
        console.error('Email send failed:', error);
        return {
          success: true,
          message: 'OTP generated but email failed. Try again.',
          expiresIn: 600
        };
      }
    }

    // Send via SMS
    if (type.includes('sms') && FEATURES.SEND_REAL_SMS) {
      try {
        await this.smsService.sendOTP(identifier, otp);
      } catch (error) {
        console.error('SMS send failed:', error);
      }
    }

    return {
      success: true,
      message: 'OTP sent successfully',
      expiresIn: 600
    };
  }

  // ===== VERIFY OTP =====
  async verifyOTP(identifier, otp, type) {
    const otpRecord = await this.OTP.findOne({
      where: { identifier, type, isUsed: false }
    });

    if (!otpRecord) {
      throw new Error('OTP not found or already used');
    }

    if (new Date() > otpRecord.expiresAt) {
      throw new Error('OTP expired');
    }

    if (otpRecord.attempts >= 3) {
      throw new Error('Max attempts exceeded');
    }

    if (otpRecord.otp !== otp) {
      otpRecord.attempts += 1;
      await otpRecord.save();
      throw new Error('Invalid OTP');
    }

    otpRecord.isUsed = true;
    await otpRecord.save();

    return { success: true, message: 'OTP verified' };
  }

  // ===== REGISTER USER =====
  async registerUser(data) {
    const { email, password, firstName, lastName, organizationName, phone } = data;

    const existingUser = await this.User.findOne({ where: { email } });
    if (existingUser) {
      throw new Error('Email already registered');
    }

    const passwordHash = await bcrypt.hash(password, 10);

    const organization = await this.Organization.create({
      id: uuidv4(),
      name: organizationName,
      subscriptionTier: 'RESTAURANT_BASIC',
      enabled_modules: ['auth', 'dashboard'],
      licenseExpiry: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
    });

    const ownerRole = await this.Role.findOne({ where: { name: 'OWNER' } });

    const user = await this.User.create({
      id: uuidv4(),
      email,
      passwordHash,
      firstName,
      lastName,
      phone,
      organizationId: organization.id,
      roleId: ownerRole.id,
      emailVerified: FEATURES.AUTO_VERIFY_EMAIL,
      isActive: true
    });

    // Generate OTP for email verification
    if (!FEATURES.AUTO_VERIFY_EMAIL) {
      await this.generateOTP(email, 'email_verification');
    }

    return {
      success: true,
      message: FEATURES.AUTO_VERIFY_EMAIL
        ? '[DEMO] Email auto-verified. You can login now!'
        : 'User registered. OTP sent to email.',
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        organizationId: user.organizationId
      }
    };
  }

  // ===== LOGIN =====
  async login(email, password) {
    const user = await this.User.findOne({ where: { email } });

    if (!user) {
      throw new Error('User not found');
    }

    if (user.lockedUntil && new Date() < user.lockedUntil) {
      throw new Error('Account locked. Try again later.');
    }

    const isValidPassword = await bcrypt.compare(password, user.passwordHash);

    if (!isValidPassword) {
      user.loginAttempts = (user.loginAttempts || 0) + 1;
      if (user.loginAttempts >= 5) {
        user.lockedUntil = new Date(Date.now() + 30 * 60 * 1000);
      }
      await user.save();
      throw new Error('Invalid password');
    }

    user.loginAttempts = 0;
    await user.save();

    // DEMO MODE - Skip 2FA
    if (FEATURES.SKIP_2FA) {
      const token = this.generateToken(user);
      return {
        success: true,
        message: '[DEMO] Login successful - 2FA skipped',
        user: {
          id: user.id,
          email: user.email,
          firstName: user.firstName,
          organizationId: user.organizationId
        },
        token: token,
        devMode: true
      };
    }

    // PRODUCTION - Require 2FA
    if (user.twoFaEnabled) {
      await this.generateOTP(email, '2fa_login');
      return {
        success: true,
        message: 'OTP sent for 2FA verification',
        requiresOTP: true,
        userId: user.id
      };
    }

    const token = this.generateToken(user);
    return {
      success: true,
      message: 'Login successful',
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        organizationId: user.organizationId
      },
      token: token
    };
  }

  // ===== TOKEN GENERATION =====
  generateToken(user) {
    return jwt.sign(
      { userId: user.id, organizationId: user.organizationId, roleId: user.roleId },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRE || '7d' }
    );
  }

  generateRefreshToken(user) {
    return jwt.sign(
      { userId: user.id },
      process.env.JWT_REFRESH_SECRET,
      { expiresIn: process.env.JWT_REFRESH_EXPIRE || '30d' }
    );
  }

  // ===== PASSWORD RESET =====
  async forgotPassword(email) {
    const user = await this.User.findOne({ where: { email } });

    if (!user) {
      return { success: true, message: 'If email exists, OTP sent' };
    }

    await this.generateOTP(email, 'forgot_password');

    return {
      success: true,
      message: 'OTP sent to email for password reset'
    };
  }

  async resetPassword(email, otp, newPassword) {
    await this.verifyOTP(email, otp, 'forgot_password');

    const user = await this.User.findOne({ where: { email } });
    const passwordHash = await bcrypt.hash(newPassword, 10);

    user.passwordHash = passwordHash;
    await user.save();

    return { success: true, message: 'Password reset successful' };
  }

  // ===== CHANGE PASSWORD =====
  async changePassword(userId, oldPassword, newPassword) {
    const user = await this.User.findByPk(userId);

    const isValidPassword = await bcrypt.compare(oldPassword, user.passwordHash);
    if (!isValidPassword) {
      throw new Error('Current password is incorrect');
    }

    const passwordHash = await bcrypt.hash(newPassword, 10);
    user.passwordHash = passwordHash;
    await user.save();

    return { success: true, message: 'Password changed successfully' };
  }

  // ===== 2FA =====
  async enable2FA(userId) {
    const user = await this.User.findByPk(userId);
    user.twoFaEnabled = true;
    await user.save();

    return { success: true, message: '2FA enabled' };
  }

  async disable2FA(userId) {
    const user = await this.User.findByPk(userId);
    user.twoFaEnabled = false;
    await user.save();

    return { success: true, message: '2FA disabled' };
  }
}

export default AuthService;
