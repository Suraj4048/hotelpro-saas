import { ApiError } from '../middleware/errorHandler.js';
import { asyncHandler } from '../middleware/errorHandler.js';
import FEATURES from '../config/features.js';

export class AuthController {
  constructor(authService) {
    this.authService = authService;
  }

  register = asyncHandler(async (req, res) => {
    const { email, password, firstName, lastName, organizationName, phone } = req.body;

    if (!email || !password || !firstName || !lastName || !organizationName) {
      throw new ApiError(400, 'All fields are required');
    }

    const result = await this.authService.registerUser({
      email,
      password,
      firstName,
      lastName,
      organizationName,
      phone
    });

    res.status(201).json({
      success: true,
      message: result.message,
      data: result.user,
      devMode: FEATURES.DEMO_MODE
    });
  });

  login = asyncHandler(async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
      throw new ApiError(400, 'Email and password are required');
    }

    const result = await this.authService.login(email, password);

    if (result.requiresOTP) {
      return res.status(200).json({
        success: true,
        message: result.message,
        requiresOTP: true,
        userId: result.userId
      });
    }

    res.status(200).json({
      success: true,
      message: result.message,
      data: result,
      devMode: FEATURES.DEMO_MODE
    });
  });

  verifyOTP = asyncHandler(async (req, res) => {
    const { email, otp, type } = req.body;

    if (!email || !otp || !type) {
      throw new ApiError(400, 'Email, OTP, and type are required');
    }

    const result = await this.authService.verifyOTP(email, otp, type);

    // After OTP verification, generate token
    const user = await this.authService.User.findOne({ where: { email } });
    const token = this.authService.generateToken(user);

    res.status(200).json({
      success: true,
      message: 'OTP verified successfully',
      data: {
        user: {
          id: user.id,
          email: user.email,
          firstName: user.firstName
        },
        token: token
      }
    });
  });

  resendOTP = asyncHandler(async (req, res) => {
    const { email, type } = req.body;

    if (!email || !type) {
      throw new ApiError(400, 'Email and type are required');
    }

    const result = await this.authService.generateOTP(email, type);

    res.status(200).json({
      success: true,
      message: result.message,
      devOtp: result.otp,
      devMode: FEATURES.DEMO_MODE
    });
  });

  forgotPassword = asyncHandler(async (req, res) => {
    const { email } = req.body;

    if (!email) {
      throw new ApiError(400, 'Email is required');
    }

    const result = await this.authService.forgotPassword(email);

    res.status(200).json({
      success: true,
      message: result.message
    });
  });

  resetPassword = asyncHandler(async (req, res) => {
    const { email, otp, newPassword } = req.body;

    if (!email || !otp || !newPassword) {
      throw new ApiError(400, 'Email, OTP, and new password are required');
    }

    const result = await this.authService.resetPassword(email, otp, newPassword);

    res.status(200).json({
      success: true,
      message: result.message
    });
  });

  getProfile = asyncHandler(async (req, res) => {
    const user = await this.authService.User.findByPk(req.user.userId);

    res.status(200).json({
      success: true,
      data: user
    });
  });

  updateProfile = asyncHandler(async (req, res) => {
    const { firstName, lastName, phone } = req.body;
    const user = await this.authService.User.findByPk(req.user.userId);

    if (firstName) user.firstName = firstName;
    if (lastName) user.lastName = lastName;
    if (phone) user.phone = phone;

    await user.save();

    res.status(200).json({
      success: true,
      message: 'Profile updated successfully',
      data: user
    });
  });

  changePassword = asyncHandler(async (req, res) => {
    const { oldPassword, newPassword } = req.body;

    if (!oldPassword || !newPassword) {
      throw new ApiError(400, 'Old and new passwords are required');
    }

    const result = await this.authService.changePassword(
      req.user.userId,
      oldPassword,
      newPassword
    );

    res.status(200).json({
      success: true,
      message: result.message
    });
  });

  enable2FA = asyncHandler(async (req, res) => {
    const result = await this.authService.enable2FA(req.user.userId);

    res.status(200).json({
      success: true,
      message: result.message
    });
  });

  disable2FA = asyncHandler(async (req, res) => {
    const result = await this.authService.disable2FA(req.user.userId);

    res.status(200).json({
      success: true,
      message: result.message
    });
  });

  logout = asyncHandler(async (req, res) => {
    res.status(200).json({
      success: true,
      message: 'Logged out successfully'
    });
  });

  refreshToken = asyncHandler(async (req, res) => {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      throw new ApiError(400, 'Refresh token is required');
    }

    try {
      const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
      const user = await this.authService.User.findByPk(decoded.userId);
      const newToken = this.authService.generateToken(user);

      res.status(200).json({
        success: true,
        data: { token: newToken }
      });
    } catch (error) {
      throw new ApiError(401, 'Invalid refresh token');
    }
  });
}

export default AuthController;
