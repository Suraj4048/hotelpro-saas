import nodemailer from 'nodemailer';
import twilio from 'twilio';
import FEATURES from '../config/features.js';

export class CommunicationService {
  constructor() {
    this.emailTransporter = this.initEmailService();
    this.smsClient = this.initSMSService();
  }

  // ===== EMAIL SERVICE =====
  initEmailService() {
    if (FEATURES.MOCK_OTP || !FEATURES.SEND_REAL_EMAILS) {
      return null;
    }

    return nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: process.env.SMTP_PORT,
      secure: true,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
      }
    });
  }

  async sendOTP(email, otp, type = 'email_verification') {
    if (FEATURES.MOCK_OTP) {
      console.log(`[DEMO EMAIL] OTP to ${email}: ${otp}`);
      return { success: true, message: 'Demo mode - email not sent' };
    }

    if (!FEATURES.SEND_REAL_EMAILS || !this.emailTransporter) {
      console.log(`[DEMO EMAIL] OTP to ${email}: ${otp}`);
      return { success: true, message: 'Email service disabled' };
    }

    try {
      const subject = this.getEmailSubject(type);
      const html = this.getEmailTemplate(otp, type);

      await this.emailTransporter.sendMail({
        from: process.env.EMAIL_FROM,
        to: email,
        subject: subject,
        html: html
      });

      return { success: true, message: 'OTP sent via email' };
    } catch (error) {
      console.error('Email send error:', error);
      throw new Error('Failed to send email');
    }
  }

  async sendWelcomeEmail(email, firstName) {
    if (FEATURES.MOCK_OTP || !FEATURES.SEND_REAL_EMAILS || !this.emailTransporter) {
      console.log(`[DEMO EMAIL] Welcome email to ${email}`);
      return { success: true };
    }

    try {
      await this.emailTransporter.sendMail({
        from: process.env.EMAIL_FROM,
        to: email,
        subject: 'Welcome to HotelPro!',
        html: `
          <h1>Welcome ${firstName}!</h1>
          <p>Your HotelPro account has been created successfully.</p>
          <p>You can now login and start using HotelPro.</p>
        `
      });

      return { success: true };
    } catch (error) {
      console.error('Welcome email error:', error);
    }
  }

  async sendPasswordResetEmail(email, otp) {
    if (FEATURES.MOCK_OTP || !FEATURES.SEND_REAL_EMAILS || !this.emailTransporter) {
      console.log(`[DEMO EMAIL] Password reset OTP to ${email}: ${otp}`);
      return { success: true };
    }

    try {
      await this.emailTransporter.sendMail({
        from: process.env.EMAIL_FROM,
        to: email,
        subject: 'Reset Your Password',
        html: this.getEmailTemplate(otp, 'forgot_password')
      });

      return { success: true };
    } catch (error) {
      console.error('Password reset email error:', error);
    }
  }

  getEmailSubject(type) {
    const subjects = {
      email_verification: 'Verify Your Email - HotelPro',
      2fa_login: 'Your 2FA Code - HotelPro',
      forgot_password: 'Reset Your Password - HotelPro',
      phone_verification: 'Verify Your Phone - HotelPro'
    };
    return subjects[type] || 'Your OTP - HotelPro';
  }

  getEmailTemplate(otp, type) {
    return `
      <div style="font-family: Arial, sans-serif; padding: 20px;">
        <h2>HotelPro</h2>
        <p>Your OTP for ${type.replace(/_/g, ' ')}: <strong>${otp}</strong></p>
        <p>This OTP is valid for 10 minutes.</p>
        <p>If you didn't request this, please ignore this email.</p>
        <hr>
        <small>HotelPro - Premium Hotel Management System</small>
      </div>
    `;
  }

  // ===== SMS SERVICE =====
  initSMSService() {
    if (FEATURES.MOCK_OTP || !FEATURES.SEND_REAL_SMS) {
      return null;
    }

    try {
      return twilio(
        process.env.TWILIO_ACCOUNT_SID,
        process.env.TWILIO_AUTH_TOKEN
      );
    } catch (error) {
      console.error('Twilio initialization failed:', error);
      return null;
    }
  }

  async sendSMS(phone, message) {
    if (FEATURES.MOCK_OTP) {
      console.log(`[DEMO SMS] Message to ${phone}: ${message}`);
      return { success: true, message: 'Demo mode - SMS not sent' };
    }

    if (!FEATURES.SEND_REAL_SMS || !this.smsClient) {
      console.log(`[DEMO SMS] Message to ${phone}: ${message}`);
      return { success: true, message: 'SMS service disabled' };
    }

    try {
      await this.smsClient.messages.create({
        body: message,
        from: process.env.TWILIO_PHONE,
        to: phone
      });

      return { success: true, message: 'SMS sent successfully' };
    } catch (error) {
      console.error('SMS send error:', error);
      throw new Error('Failed to send SMS');
    }
  }

  async sendOTPViaSMS(phone, otp) {
    const message = `Your HotelPro OTP is: ${otp}. Valid for 10 minutes.`;
    return this.sendSMS(phone, message);
  }

  async sendAlert(phone, message) {
    return this.sendSMS(phone, message);
  }
}

export default CommunicationService;
