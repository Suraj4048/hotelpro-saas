# HotelPro - Demo Mode Update

## 📁 What's Inside

5 Updated Files for Demo/Real OTP Toggle:

```
hotelpro-demo/
└── backend/
    ├── .env.example (UPDATED)
    └── src/
        ├── config/
        │   └── features.js (NEW)
        ├── routes/01_auth/
        │   ├── auth.service.js (UPDATED)
        │   └── auth.controller.js (UPDATED)
        └── services/
            └── communication.js (UPDATED)
```

## 🚀 How to Use in Codespace

### Step 1: Copy Files
Extract this ZIP in your Codespace, then copy files to your repository:

```bash
# From Codespace terminal
cp -r hotelpro-demo/backend/* your-hotelpro-repo/backend/
```

### Step 2: Check files
```bash
cd your-hotelpro-repo
git status
# Should show 5 files changed/added
```

### Step 3: Test (Optional)
```bash
npm install
npm start
```

### Step 4: Commit & Push
```bash
git add .
git commit -m "Phase 1: Add Demo/Real OTP toggle system"
git push origin main
```

## 🎛️ How It Works

### Demo Mode (Default)
- `DEMO_MODE=true` in .env
- Dummy OTP in console
- No email/SMS sent
- All functions work without real APIs

### Real Mode (Later)
- Change `.env`: `DEMO_MODE=false`
- Add real credentials (SMTP, Twilio)
- Real OTP via email/SMS
- Same code works!

## 📝 Files Explained

1. **features.js** - Central configuration (NEW)
   - All demo/real toggles in one place
   - Import in auth.service.js, auth.controller.js, communication.js

2. **auth.service.js** - OTP generation logic (UPDATED)
   - Uses FEATURES.MOCK_OTP to decide
   - Works in demo and production

3. **auth.controller.js** - API handlers (UPDATED)
   - register() - Auto email verify in demo
   - login() - Skip 2FA in demo
   - Shows devMode flag in response

4. **communication.js** - Email & SMS (UPDATED)
   - Checks FEATURES before sending
   - Logs mock emails/SMS to console

5. **.env.example** - Configuration template (UPDATED)
   - `DEMO_MODE=true` by default
   - Comments for real mode setup

## ✅ What Changed

Only 5 files touched:
- 14 other files completely untouched
- No breaking changes
- Fully backward compatible
- Safe to push anytime

## 🔄 Demo → Real Switch (Later)

Just 2 changes needed:

```bash
# 1. Change .env
DEMO_MODE=false

# 2. Add real credentials
SMTP_HOST=smtp.gmail.com
TWILIO_ACCOUNT_SID=xxx
# ... etc

# Push it!
git add .env
git commit -m "Enable real OTP"
git push
```

That's it! No code changes needed! ✅

## 🆘 Need Help?

- All files have comments
- Same structure as original
- features.js is the control center
- Other files just import it

Ready to go! 🚀
