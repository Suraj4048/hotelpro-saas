import Joi from 'joi';

const validateCreatePlan = (data) => {
  const schema = Joi.object({
    name: Joi.string()
      .required()
      .valid('RESTAURANT_BASIC', 'RESTAURANT_PRO', 'HOTEL_BASIC', 'FULL_SERVICE')
      .messages({
        'any.only': 'Plan name must be one of: RESTAURANT_BASIC, RESTAURANT_PRO, HOTEL_BASIC, FULL_SERVICE',
      }),
    display_name: Joi.string().required().max(100),
    description: Joi.string().max(500),
    price: Joi.number().required().positive(),
    billing_cycle: Joi.string().valid('monthly', 'yearly').default('monthly'),
    max_users: Joi.number().default(10).min(1),
    max_properties: Joi.number().default(1).min(1),
    enabled_modules: Joi.array()
      .items(
        Joi.string().valid(
          'auth',
          'dashboard',
          'pms',
          'restaurant',
          'bar',
          'banquet',
          'billing',
          'inventory',
          'hr',
          'housekeeping',
          'reporting',
          'integrations'
        )
      )
      .default([]),
    features: Joi.object({
      api_access: Joi.boolean().default(true),
      custom_branding: Joi.boolean().default(false),
      dedicated_support: Joi.boolean().default(false),
      sso: Joi.boolean().default(false),
      advanced_reporting: Joi.boolean().default(false),
      white_label: Joi.boolean().default(false),
    }).default({}),
    trial_days: Joi.number().default(14).min(0),
    is_active: Joi.boolean().default(true),
  });

  return schema.validate(data, { abortEarly: false });
};

const validateUpdateClient = (data) => {
  const schema = Joi.object({
    name: Joi.string().max(255),
    email: Joi.string().email(),
    phone: Joi.string().max(20),
    address: Joi.string().max(500),
    city: Joi.string().max(100),
    state: Joi.string().max(100),
    country: Joi.string().max(100),
    contact_person: Joi.string().max(255),
    website: Joi.string().uri().allow(null),
    status: Joi.string().valid('active', 'inactive', 'trial', 'suspended'),
  });

  return schema.validate(data, { abortEarly: false });
};

const validateToggleModule = (data) => {
  const schema = Joi.object({
    moduleName: Joi.string()
      .required()
      .valid(
        'auth',
        'dashboard',
        'pms',
        'restaurant',
        'bar',
        'banquet',
        'billing',
        'inventory',
        'hr',
        'housekeeping',
        'reporting',
        'integrations'
      ),
    enable: Joi.boolean().required(),
  });

  return schema.validate(data, { abortEarly: false });
};

const validateCreateSubscription = (data) => {
  const schema = Joi.object({
    planId: Joi.string().uuid().required(),
    billingEmail: Joi.string().email(),
  });

  return schema.validate(data, { abortEarly: false });
};

const validateUpgradePlan = (data) => {
  const schema = Joi.object({
    newPlanId: Joi.string().uuid().required(),
  });

  return schema.validate(data, { abortEarly: false });
};

export {
  validateCreatePlan,
  validateUpdateClient,
  validateToggleModule,
  validateCreateSubscription,
  validateUpgradePlan,
};
