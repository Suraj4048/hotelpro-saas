# Phase 3: Admin Panel & Subscription Management API

## Overview
Phase 3 introduces a comprehensive admin panel for managing clients, subscriptions, and revenue tracking. Only users with `SUPER_ADMIN` role can access these endpoints.

---

## Database Models

### 1. SubscriptionPlan
Defines available subscription plans.

```javascript
{
  id: UUID (PK),
  name: ENUM ('RESTAURANT_BASIC', 'RESTAURANT_PRO', 'HOTEL_BASIC', 'FULL_SERVICE'),
  display_name: STRING,
  description: TEXT,
  price: DECIMAL(10,2),
  billing_cycle: ENUM ('monthly', 'yearly'),
  max_users: INTEGER,
  max_properties: INTEGER,
  enabled_modules: JSON [],
  features: JSON {},
  trial_days: INTEGER,
  is_active: BOOLEAN,
  created_at: TIMESTAMP,
  updated_at: TIMESTAMP
}
```

### 2. ClientSubscription
Tracks each client's subscription details.

```javascript
{
  id: UUID (PK),
  organization_id: UUID (FK → organizations),
  subscription_plan_id: UUID (FK → subscription_plans),
  status: ENUM ('trial', 'active', 'paused', 'cancelled', 'expired'),
  current_period_start: TIMESTAMP,
  current_period_end: TIMESTAMP,
  trial_end_date: TIMESTAMP,
  auto_renew: BOOLEAN,
  billing_email: STRING,
  payment_method: ENUM ('credit_card', 'bank_transfer', 'upi', 'manual'),
  notes: TEXT,
  cancelled_at: TIMESTAMP,
  cancelled_reason: TEXT,
  created_at: TIMESTAMP,
  updated_at: TIMESTAMP
}
```

### 3. SubscriptionHistory
Audit trail of all subscription changes.

```javascript
{
  id: UUID (PK),
  organization_id: UUID (FK),
  client_subscription_id: UUID (FK),
  event_type: ENUM ('subscription_created', 'subscription_upgraded', ...),
  old_plan_id: UUID (FK),
  new_plan_id: UUID (FK),
  amount: DECIMAL(10,2),
  notes: TEXT,
  triggered_by: STRING,
  created_at: TIMESTAMP
}
```

---

## API Endpoints

### Authentication
All endpoints require:
- **Authorization Header**: `Bearer <JWT_TOKEN>`
- **User Role**: `SUPER_ADMIN`

### Response Format
Success:
```json
{
  "success": true,
  "data": { ... },
  "message": "...",
  "count": 10
}
```

Error:
```json
{
  "success": false,
  "error": "Error message"
}
```

---

## Subscription Plans

### 1. Get All Plans
```
GET /api/admin/plans
```

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "uuid",
      "name": "HOTEL_BASIC",
      "display_name": "Hotel - Basic",
      "price": 8000,
      "enabled_modules": ["auth", "dashboard", "pms", "housekeeping", "billing", "reports"],
      "max_users": 15,
      "trial_days": 14
    }
  ]
}
```

### 2. Get Specific Plan
```
GET /api/admin/plans/:planId
```

### 3. Create Plan
```
POST /api/admin/plans
Content-Type: application/json

{
  "name": "RESTAURANT_BASIC",
  "display_name": "Restaurant - Basic",
  "description": "Perfect for small restaurants",
  "price": 5000,
  "billing_cycle": "monthly",
  "max_users": 10,
  "max_properties": 1,
  "enabled_modules": ["auth", "dashboard", "restaurant", "billing", "reports"],
  "features": {
    "api_access": true,
    "custom_branding": false,
    "dedicated_support": false
  },
  "trial_days": 14
}
```

### 4. Update Plan
```
PUT /api/admin/plans/:planId
Content-Type: application/json

{
  "price": 6000,
  "max_users": 20
}
```

### 5. Deactivate Plan
```
DELETE /api/admin/plans/:planId
```

---

## Client Management

### 1. Get All Clients
```
GET /api/admin/clients?status=active&search=hotel
```

**Query Parameters:**
- `status`: 'active', 'inactive', 'trial', 'suspended'
- `search`: Search by name or email

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "org-uuid",
      "name": "The Grand Hotel",
      "email": "info@grandhotel.com",
      "status": "active",
      "enabled_modules": ["auth", "dashboard", "pms", ...],
      "ClientSubscriptions": [
        {
          "id": "sub-uuid",
          "status": "active",
          "current_period_end": "2025-11-05",
          "SubscriptionPlan": { "display_name": "Hotel - Basic", "price": 8000 }
        }
      ]
    }
  ],
  "count": 25
}
```

### 2. Get Specific Client
```
GET /api/admin/clients/:clientId
```

### 3. Update Client
```
PUT /api/admin/clients/:clientId
Content-Type: application/json

{
  "name": "The Grand Hotel",
  "email": "contact@grandhotel.com",
  "phone": "+91-9999999999",
  "address": "123 Main Street",
  "city": "Mumbai",
  "country": "India",
  "contact_person": "John Doe",
  "website": "https://grandhotel.com"
}
```

### 4. Deactivate Client
```
POST /api/admin/clients/:clientId/deactivate
Content-Type: application/json

{
  "reason": "Payment failed, inactive for 3 months"
}
```

This endpoint:
- Sets client status to `inactive`
- Cancels active subscription
- Logs cancellation in history
- Disables all modules

---

## Subscription Management

### 1. Get Client's Subscription
```
GET /api/admin/clients/:clientId/subscription
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "sub-uuid",
    "organization_id": "client-uuid",
    "status": "active",
    "current_period_start": "2025-10-05",
    "current_period_end": "2025-11-05",
    "trial_end_date": "2025-10-19",
    "auto_renew": true,
    "SubscriptionPlan": {
      "id": "plan-uuid",
      "display_name": "Hotel - Basic",
      "price": 8000
    }
  }
}
```

### 2. Create Subscription for Client
```
POST /api/admin/clients/:clientId/subscription
Content-Type: application/json

{
  "planId": "plan-uuid",
  "billingEmail": "billing@grandhotel.com"
}
```

**Note:** Automatically:
- Sets subscription status to `trial`
- Assigns trial period (14 days by default)
- Enables modules from the plan
- Logs to subscription history

### 3. Upgrade Plan
```
POST /api/admin/clients/:clientId/subscription/upgrade
Content-Type: application/json

{
  "newPlanId": "new-plan-uuid"
}
```

**Features:**
- Calculates prorated amount
- Updates enabled modules
- Extends period end date
- Logs upgrade in history
- Tracks old and new plan

### 4. Toggle Module Access
```
POST /api/admin/clients/:clientId/modules/toggle
Content-Type: application/json

{
  "moduleName": "restaurant",
  "enable": true
}
```

**Available Modules:**
- auth
- dashboard
- pms
- restaurant
- bar
- banquet
- billing
- inventory
- hr
- housekeeping
- reporting
- integrations

### 5. Get Subscription History
```
GET /api/admin/clients/:clientId/subscription/history
```

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "history-uuid",
      "event_type": "subscription_upgraded",
      "old_plan_id": "plan-1-uuid",
      "new_plan_id": "plan-2-uuid",
      "amount": 2000,
      "triggered_by": "admin-id",
      "notes": "Upgraded from Basic to Pro",
      "created_at": "2025-10-05T10:30:00Z"
    }
  ],
  "count": 15
}
```

---

## Admin Dashboard

### 1. Get Dashboard Stats
```
GET /api/admin/dashboard
```

**Response:**
```json
{
  "success": true,
  "data": {
    "totalClients": 45,
    "activeSubscriptions": 38,
    "trialSubscriptions": 5,
    "totalRevenue": 285000,
    "mrr": 285000,
    "subscriptionsByStatus": {
      "active": 38,
      "trial": 5,
      "paused": 2,
      "cancelled": 0
    }
  }
}
```

### 2. Get Revenue Stats
```
GET /api/admin/revenue?period=monthly
```

**Query Parameters:**
- `period`: 'monthly' (default) | 'yearly'

**Response:**
```json
{
  "success": true,
  "data": {
    "period": "monthly",
    "totalMRR": 285000,
    "revenueByPlan": {
      "Restaurant - Basic": {
        "count": 12,
        "revenue": 60000
      },
      "Hotel - Basic": {
        "count": 20,
        "revenue": 160000
      },
      "Full Service": {
        "count": 6,
        "revenue": 150000
      }
    },
    "totalActiveSubscriptions": 38,
    "clientsWithSubscriptions": 38
  }
}
```

---

## Business Logic Rules

### Subscription States
```
trial → active → renewal cycle
    ↓
paused → active (manual intervention)
    ↓
cancelled (permanent)
```

### Automatic Actions
1. **Trial to Active**: After trial period expires
2. **Renewal**: If `auto_renew` is true on period end
3. **Cancellation**: Manual or due to payment failure
4. **Expiration**: If not renewed after current period

### Module Logic
- Enabling module: Added to client's `enabled_modules[]`
- Disabling module: Removed from `enabled_modules[]`
- Plan upgrade: New modules added automatically
- Plan downgrade: Module removal needs manual confirmation

### Revenue Calculation
- **MRR** = Sum of all active subscription prices
- **Prorated** = (new_price - old_price) * remaining_days / total_days
- **History** = All changes tracked in SubscriptionHistory

---

## Default Subscription Plans

### RESTAURANT_BASIC (₹5,000/month)
**Modules:** auth, dashboard, restaurant, billing, reports  
**Max Users:** 10  
**Features:** API access only

### RESTAURANT_PRO (₹10,000/month)
**Modules:** BASIC + inventory, integrations  
**Max Users:** 25  
**Features:** API access, Custom branding

### HOTEL_BASIC (₹8,000/month)
**Modules:** auth, dashboard, pms, housekeeping, billing, reports  
**Max Users:** 15  
**Features:** API access

### FULL_SERVICE (₹25,000/month)
**Modules:** All 12 modules  
**Max Users:** 50  
**Features:** All premium features + Dedicated support

---

## Error Codes

| Code | Message | Solution |
|------|---------|----------|
| 400 | Bad request | Check request body/parameters |
| 401 | Unauthorized | Missing or invalid token |
| 403 | Forbidden | User doesn't have SUPER_ADMIN role |
| 404 | Not found | Resource doesn't exist |
| 500 | Server error | Contact support |

---

## Rate Limiting
Currently: No rate limits (implement as needed)

---

## Future Enhancements
- [ ] Payment gateway integration (Razorpay, Stripe)
- [ ] Automatic billing & invoice generation
- [ ] Usage analytics per client
- [ ] Custom pricing tiers
- [ ] Volume discounts
- [ ] Seat-based billing
- [ ] API quota management
