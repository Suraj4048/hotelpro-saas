# Phase 3: Admin Panel - Quick Guide 🚀

## What's in Phase 3?

A complete admin panel system for managing clients, subscriptions, and revenue tracking.

---

## Files Included (10 files)

### Models (3 files)
| File | Purpose |
|------|---------|
| `SubscriptionPlan.js` | Plan definitions (BASIC, PRO, FULL_SERVICE) |
| `ClientSubscription.js` | Client subscription tracking |
| `SubscriptionHistory.js` | Audit trail of changes |

### Admin Module (4 files)
| File | Purpose |
|------|---------|
| `admin.service.js` | Business logic (270+ lines) |
| `admin.controller.js` | API handlers (250+ lines) |
| `admin.routes.js` | Route definitions (50+ lines) |
| `admin.validators.js` | Input validation (120+ lines) |

### Middleware & Utilities (2 files)
| File | Purpose |
|------|---------|
| `authMiddleware.js` | Role-based access control |
| `setup-phase3.sh` | Automated deployment script |

### Documentation
| File | Purpose |
|------|---------|
| `PHASE3_ADMIN_API_DOCUMENTATION.md` | Complete API reference |

---

## Deployment Steps

### Step 1: Download ZIP
Download **`hotelpro-phase3.zip`** from this chat

### Step 2: Upload to Codespace
In VS Code Codespace:
1. Click **Explorer** → right-click `/workspaces` folder
2. Select **Upload Files**
3. Choose `hotelpro-phase3.zip`
4. Wait for upload to complete

### Step 3: Run Setup Command
Copy-paste this one command in your terminal:

```bash
cd /workspaces/hotelpro-saas && unzip -o /workspaces/hotelpro-phase3.zip -d /workspaces && bash /workspaces/hotelpro-phase3/setup-phase3.sh
```

### Step 4: Verify
Script will:
- ✅ Copy all model files to `backend/src/models/`
- ✅ Copy admin module to `backend/src/routes/03_admin/`
- ✅ Update `backend/src/server.js` with admin routes
- ✅ Create git commit: "Phase 3: Admin Panel & Subscription Management"
- ✅ Push to GitHub

---

## Admin Routes (13 endpoints)

### Plans
```
GET    /api/admin/plans              - Get all plans
GET    /api/admin/plans/:planId      - Get specific plan
POST   /api/admin/plans              - Create plan
PUT    /api/admin/plans/:planId      - Update plan
DELETE /api/admin/plans/:planId      - Deactivate plan
```

### Clients
```
GET    /api/admin/clients            - Get all clients
GET    /api/admin/clients/:clientId  - Get specific client
PUT    /api/admin/clients/:clientId  - Update client
POST   /api/admin/clients/:clientId/deactivate  - Deactivate client
```

### Subscriptions
```
GET    /api/admin/clients/:clientId/subscription              - Get subscription
POST   /api/admin/clients/:clientId/subscription              - Create subscription
POST   /api/admin/clients/:clientId/subscription/upgrade      - Upgrade plan
POST   /api/admin/clients/:clientId/modules/toggle            - Enable/disable module
GET    /api/admin/clients/:clientId/subscription/history      - Get change history
```

### Dashboard
```
GET    /api/admin/dashboard          - Admin stats (MRR, clients, etc)
GET    /api/admin/revenue            - Revenue analytics
```

---

## Admin Dashboard Features

Display key business metrics:
- **Total Clients** - How many organizations are onboarded
- **Active Subscriptions** - Currently paying customers
- **Trial Subscriptions** - Free trial users
- **MRR** (Monthly Recurring Revenue) - Total monthly revenue
- **Subscriptions by Status** - Breakdown by active/paused/cancelled
- **Revenue by Plan** - How much each plan generates

---

## Default Subscription Plans

| Plan | Price | Modules | Users |
|------|-------|---------|-------|
| RESTAURANT_BASIC | ₹5,000 | 5 modules | 10 users |
| RESTAURANT_PRO | ₹10,000 | 7 modules | 25 users |
| HOTEL_BASIC | ₹8,000 | 6 modules | 15 users |
| FULL_SERVICE | ₹25,000 | All 12 | 50 users |

**Modules:**
auth, dashboard, pms, restaurant, bar, banquet, billing, inventory, hr, housekeeping, reporting, integrations

---

## Key Features

### 1. Multi-Tenant Support
- Each client (organization) has own subscription
- Modules enabled/disabled per client
- Separate database rows, one codebase

### 2. Subscription Lifecycle
```
Trial (14 days) → Active → Renewal → Cancelled
```

### 3. Module Control
Enable/disable specific features per client:
```
POST /api/admin/clients/{id}/modules/toggle
{
  "moduleName": "restaurant",
  "enable": true
}
```

### 4. Revenue Tracking
- Track MRR (Monthly Recurring Revenue)
- Revenue by plan breakdown
- Subscription history audit trail

### 5. Client Management
- Add/edit/delete organizations
- Change subscription plan
- View subscription details
- Cancel with reason tracking

---

## Admin Role Only

All admin endpoints require:
- **JWT Token** in Authorization header
- **SUPER_ADMIN role** (verified by middleware)

Regular users cannot access `/api/admin/*`

---

## Database Impact

4 new tables created:
- `subscription_plans` - Plan definitions
- `client_subscriptions` - Client subscription records
- `subscription_history` - Audit trail
- Uses existing `organizations` table

---

## Next: Phase 4 - PMS Module

After Phase 3 is deployed, we'll build:
- **Property Management System**
- Room inventory management
- Reservation engine
- Check-in/check-out workflow
- Guest profiles
- Room status tracking

---

## Files Modified

Only `backend/src/server.js` is modified:
- Adds import for admin routes
- Registers `/api/admin` route handler
- No other files touched (safe!)

---

## Rollback (if needed)

If something goes wrong:
```bash
git revert HEAD  # Undo last commit
git push origin main  # Push to GitHub
```

---

## Support

- Check `PHASE3_ADMIN_API_DOCUMENTATION.md` for detailed API reference
- All error codes and responses documented
- Business logic rules clearly defined

---

## Ready? 🚀

1. Download `hotelpro-phase3.zip`
2. Upload to Codespace
3. Run setup command
4. Take screenshot of success
5. Share with me!

**Then we build Phase 4: PMS Module**
