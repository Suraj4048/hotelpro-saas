import * as adminService from './admin.service.js';
import { validateCreatePlan, validateUpdateClient, validateToggleModule } from './admin.validators.js';

// ============ SUBSCRIPTION PLANS ============

export const getAllPlans = async (req, res) => {
  try {
    const plans = await adminService.getAllPlans();
    return res.json({
      success: true,
      data: plans,
      message: 'Plans fetched successfully',
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      error: error.message,
    });
  }
};

export const getPlanById = async (req, res) => {
  try {
    const { planId } = req.params;
    const plan = await adminService.getPlanById(planId);

    if (!plan) {
      return res.status(404).json({
        success: false,
        error: 'Plan not found',
      });
    }

    return res.json({
      success: true,
      data: plan,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      error: error.message,
    });
  }
};

export const createPlan = async (req, res) => {
  try {
    const { error, value } = validateCreatePlan(req.body);
    if (error) {
      return res.status(400).json({
        success: false,
        error: error.message,
      });
    }

    const plan = await adminService.createPlan(value);
    return res.status(201).json({
      success: true,
      data: plan,
      message: 'Plan created successfully',
    });
  } catch (error) {
    return res.status(400).json({
      success: false,
      error: error.message,
    });
  }
};

export const updatePlan = async (req, res) => {
  try {
    const { planId } = req.params;
    const plan = await adminService.updatePlan(planId, req.body);

    return res.json({
      success: true,
      data: plan,
      message: 'Plan updated successfully',
    });
  } catch (error) {
    return res.status(400).json({
      success: false,
      error: error.message,
    });
  }
};

export const deactivatePlan = async (req, res) => {
  try {
    const { planId } = req.params;
    const plan = await adminService.deactivatePlan(planId);

    return res.json({
      success: true,
      data: plan,
      message: 'Plan deactivated successfully',
    });
  } catch (error) {
    return res.status(400).json({
      success: false,
      error: error.message,
    });
  }
};

// ============ CLIENT MANAGEMENT ============

export const getAllClients = async (req, res) => {
  try {
    const { status, search } = req.query;
    const clients = await adminService.getAllClients({ status, search });

    return res.json({
      success: true,
      data: clients,
      count: clients.length,
      message: 'Clients fetched successfully',
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      error: error.message,
    });
  }
};

export const getClientById = async (req, res) => {
  try {
    const { clientId } = req.params;
    const client = await adminService.getClientById(clientId);

    return res.json({
      success: true,
      data: client,
    });
  } catch (error) {
    return res.status(404).json({
      success: false,
      error: error.message,
    });
  }
};

export const updateClient = async (req, res) => {
  try {
    const { clientId } = req.params;
    const { error, value } = validateUpdateClient(req.body);

    if (error) {
      return res.status(400).json({
        success: false,
        error: error.message,
      });
    }

    const client = await adminService.updateClient(clientId, value);

    return res.json({
      success: true,
      data: client,
      message: 'Client updated successfully',
    });
  } catch (error) {
    return res.status(400).json({
      success: false,
      error: error.message,
    });
  }
};

export const deactivateClient = async (req, res) => {
  try {
    const { clientId } = req.params;
    const { reason } = req.body;

    const client = await adminService.deactivateClient(clientId, reason);

    return res.json({
      success: true,
      data: client,
      message: 'Client deactivated and subscription cancelled',
    });
  } catch (error) {
    return res.status(400).json({
      success: false,
      error: error.message,
    });
  }
};

// ============ SUBSCRIPTION MANAGEMENT ============

export const getClientSubscription = async (req, res) => {
  try {
    const { clientId } = req.params;
    const subscription = await adminService.getClientSubscription(clientId);

    if (!subscription) {
      return res.status(404).json({
        success: false,
        error: 'No active subscription found for this client',
      });
    }

    return res.json({
      success: true,
      data: subscription,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      error: error.message,
    });
  }
};

export const createClientSubscription = async (req, res) => {
  try {
    const { clientId } = req.params;
    const { planId, billingEmail } = req.body;

    if (!planId) {
      return res.status(400).json({
        success: false,
        error: 'planId is required',
      });
    }

    const subscription = await adminService.createClientSubscription(
      clientId,
      planId,
      billingEmail
    );

    return res.status(201).json({
      success: true,
      data: subscription,
      message: 'Subscription created successfully',
    });
  } catch (error) {
    return res.status(400).json({
      success: false,
      error: error.message,
    });
  }
};

export const upgradePlan = async (req, res) => {
  try {
    const { clientId } = req.params;
    const { newPlanId } = req.body;

    if (!newPlanId) {
      return res.status(400).json({
        success: false,
        error: 'newPlanId is required',
      });
    }

    const subscription = await adminService.upgradePlan(
      clientId,
      newPlanId,
      req.user.id
    );

    return res.json({
      success: true,
      data: subscription,
      message: 'Plan upgraded successfully',
    });
  } catch (error) {
    return res.status(400).json({
      success: false,
      error: error.message,
    });
  }
};

export const toggleModule = async (req, res) => {
  try {
    const { clientId } = req.params;
    const { moduleName, enable } = req.body;

    const { error } = validateToggleModule({ moduleName, enable });
    if (error) {
      return res.status(400).json({
        success: false,
        error: error.message,
      });
    }

    const result = await adminService.toggleModule(
      clientId,
      moduleName,
      enable,
      req.user.id
    );

    return res.json({
      success: true,
      data: result,
      message: `Module ${moduleName} ${enable ? 'enabled' : 'disabled'}`,
    });
  } catch (error) {
    return res.status(400).json({
      success: false,
      error: error.message,
    });
  }
};

// ============ ADMIN DASHBOARD ============

export const getAdminDashboard = async (req, res) => {
  try {
    const dashboard = await adminService.getAdminDashboard();

    return res.json({
      success: true,
      data: dashboard,
      message: 'Admin dashboard data fetched',
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      error: error.message,
    });
  }
};

export const getRevenueStats = async (req, res) => {
  try {
    const { period = 'monthly' } = req.query;
    const stats = await adminService.getRevenueStats(period);

    return res.json({
      success: true,
      data: stats,
      message: 'Revenue stats fetched',
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      error: error.message,
    });
  }
};

export const getSubscriptionHistory = async (req, res) => {
  try {
    const { clientId } = req.params;
    const history = await adminService.getSubscriptionHistory(clientId);

    return res.json({
      success: true,
      data: history,
      count: history.length,
      message: 'Subscription history fetched',
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      error: error.message,
    });
  }
};

export default {
  getAllPlans,
  getPlanById,
  createPlan,
  updatePlan,
  deactivatePlan,
  getAllClients,
  getClientById,
  updateClient,
  deactivateClient,
  getClientSubscription,
  createClientSubscription,
  upgradePlan,
  toggleModule,
  getAdminDashboard,
  getRevenueStats,
  getSubscriptionHistory,
};
