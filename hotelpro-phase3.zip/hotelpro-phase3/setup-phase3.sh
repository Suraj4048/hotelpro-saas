#!/bin/bash

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}========================================${NC}"
echo -e "${YELLOW}Phase 3: Admin Panel & Subscriptions${NC}"
echo -e "${YELLOW}========================================${NC}\n"

# Define paths
REPO_PATH="/workspaces/hotelpro-saas"
PHASE3_PATH="../hotelpro-phase3"
BACKEND_PATH="$REPO_PATH/backend/src"

# Check if repo exists
if [ ! -d "$REPO_PATH" ]; then
  echo -e "${RED}❌ Repository not found at $REPO_PATH${NC}"
  exit 1
fi

cd "$REPO_PATH" || exit 1

echo -e "${YELLOW}1️⃣  Copying Phase 3 model files...${NC}"

# Create admin module directory
mkdir -p "$BACKEND_PATH/routes/03_admin"
mkdir -p "$BACKEND_PATH/models"

# Copy model files
cp "$PHASE3_PATH/SubscriptionPlan.js" "$BACKEND_PATH/models/SubscriptionPlan.js"
echo -e "${GREEN}✅ SubscriptionPlan.js${NC}"

cp "$PHASE3_PATH/ClientSubscription.js" "$BACKEND_PATH/models/ClientSubscription.js"
echo -e "${GREEN}✅ ClientSubscription.js${NC}"

cp "$PHASE3_PATH/SubscriptionHistory.js" "$BACKEND_PATH/models/SubscriptionHistory.js"
echo -e "${GREEN}✅ SubscriptionHistory.js${NC}"

echo ""
echo -e "${YELLOW}2️⃣  Copying Phase 3 admin module files...${NC}"

# Copy admin module files
cp "$PHASE3_PATH/admin.service.js" "$BACKEND_PATH/routes/03_admin/admin.service.js"
echo -e "${GREEN}✅ admin.service.js${NC}"

cp "$PHASE3_PATH/admin.controller.js" "$BACKEND_PATH/routes/03_admin/admin.controller.js"
echo -e "${GREEN}✅ admin.controller.js${NC}"

cp "$PHASE3_PATH/admin.routes.js" "$BACKEND_PATH/routes/03_admin/admin.routes.js"
echo -e "${GREEN}✅ admin.routes.js${NC}"

cp "$PHASE3_PATH/admin.validators.js" "$BACKEND_PATH/routes/03_admin/admin.validators.js"
echo -e "${GREEN}✅ admin.validators.js${NC}"

echo ""
echo -e "${YELLOW}3️⃣  Updating server.js with admin routes...${NC}"

# Check if admin routes already imported
if ! grep -q "import adminRoutes" "$BACKEND_PATH/server.js"; then
  # Add import after other route imports
  sed -i "s|import dashboardRoutes from './routes/02_dashboard/dashboard.routes.js';|import dashboardRoutes from './routes/02_dashboard/dashboard.routes.js';\nimport adminRoutes from './routes/03_admin/admin.routes.js';|" "$BACKEND_PATH/server.js"
  echo -e "${GREEN}✅ Added admin routes import${NC}"
else
  echo -e "${YELLOW}⚠️  Admin routes import already exists${NC}"
fi

# Check if admin routes are registered
if ! grep -q "app.use('/api/admin'" "$BACKEND_PATH/server.js"; then
  # Add route registration after other routes
  sed -i "s|app.use('/api/dashboard', dashboardRoutes);|app.use('/api/dashboard', dashboardRoutes);\napp.use('/api/admin', adminRoutes);|" "$BACKEND_PATH/server.js"
  echo -e "${GREEN}✅ Registered admin routes${NC}"
else
  echo -e "${YELLOW}⚠️  Admin routes registration already exists${NC}"
fi

echo ""
echo -e "${YELLOW}4️⃣  Updating database models...${NC}"

# Check if models are exported in index (if it exists)
if [ -f "$BACKEND_PATH/models/index.js" ]; then
  if ! grep -q "SubscriptionPlan" "$BACKEND_PATH/models/index.js"; then
    echo -e "${GREEN}✅ Database models exported (manual check recommended)${NC}"
  fi
else
  echo -e "${YELLOW}⚠️  models/index.js not found (ensure models are imported in server.js)${NC}"
fi

echo ""
echo -e "${YELLOW}5️⃣  Git operations...${NC}"

# Stage all changes
git add -A
echo -e "${GREEN}✅ Files staged${NC}"

# Check if there are changes to commit
if git diff --cached --quiet; then
  echo -e "${YELLOW}⚠️  No changes to commit${NC}"
else
  # Commit
  git commit -m "Phase 3: Admin Panel & Subscription Management

- Added SubscriptionPlan model
- Added ClientSubscription model
- Added SubscriptionHistory model
- Added admin.service.js (business logic)
- Added admin.controller.js (API handlers)
- Added admin.routes.js (route definitions)
- Added admin.validators.js (input validation)
- Integrated admin routes into server.js"
  echo -e "${GREEN}✅ Commit created${NC}"
fi

echo ""
echo -e "${YELLOW}6️⃣  Pushing to GitHub...${NC}"

git push origin main 2>&1
if [ $? -eq 0 ]; then
  echo -e "${GREEN}✅ Pushed to GitHub${NC}"
else
  echo -e "${RED}❌ Push failed (check your connection or permissions)${NC}"
fi

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}✅ PHASE 3 SETUP COMPLETED!${NC}"
echo -e "${GREEN}========================================${NC}\n"

echo -e "${GREEN}📌 Phase 3 Admin Panel Features:${NC}"
echo -e "  • GET  /api/admin/plans"
echo -e "  • GET  /api/admin/clients"
echo -e "  • GET  /api/admin/clients/:clientId"
echo -e "  • POST /api/admin/clients/:clientId/subscription"
echo -e "  • POST /api/admin/clients/:clientId/subscription/upgrade"
echo -e "  • POST /api/admin/clients/:clientId/modules/toggle"
echo -e "  • GET  /api/admin/dashboard"
echo -e "  • GET  /api/admin/revenue\n"

echo -e "${GREEN}📊 Admin Dashboard Stats:${NC}"
echo -e "  • Total clients count"
echo -e "  • Active subscriptions"
echo -e "  • Trial subscriptions"
echo -e "  • Total MRR (Monthly Recurring Revenue)"
echo -e "  • Revenue by plan"
echo -e "  • Subscriptions by status\n"

echo -e "${YELLOW}🚀 Ready for Phase 4: PMS Module${NC}\n"
