import Organization from '../models/Organization.js';
import User from '../models/User.js';
import SubscriptionPlan from '../models/SubscriptionPlan.js';
import ClientSubscription from '../models/ClientSubscription.js';
import SubscriptionHistory from '../models/SubscriptionHistory.js';
import { Op } from 'sequelize';

// ============ SUBSCRIPTION PLANS ============

export const getAllPlans = async () => {
  return await SubscriptionPlan.findAll({
    where: { is_active: true },
    order: [['price', 'ASC']],
  });
};

export const getPlanById = async (planId) => {
  return await SubscriptionPlan.findByPk(planId);
};

export const createPlan = async (planData) => {
  const existingPlan = await SubscriptionPlan.findOne({
    where: { name: planData.name },
  });
  
  if (existingPlan) {
    throw new Error('Plan with this name already exists');
  }

  return await SubscriptionPlan.create(planData);
};

export const updatePlan = async (planId, updateData) => {
  const plan = await SubscriptionPlan.findByPk(planId);
  if (!plan) {
    throw new Error('Plan not found');
  }

  return await plan.update(updateData);
};

export const deactivatePlan = async (planId) => {
  const plan = await SubscriptionPlan.findByPk(planId);
  if (!plan) {
    throw new Error('Plan not found');
  }

  return await plan.update({ is_active: false });
};

// ============ CLIENT MANAGEMENT ============

export const getAllClients = async (filters = {}) => {
  const where = {};

  if (filters.status) {
    where.status = filters.status;
  }
  if (filters.search) {
    where[Op.or] = [
      { name: { [Op.iLike]: `%${filters.search}%` } },
      { email: { [Op.iLike]: `%${filters.search}%` } },
    ];
  }

  return await Organization.findAll({
    where,
    include: [
      {
        model: ClientSubscription,
        include: [SubscriptionPlan],
      },
      {
        model: User,
        attributes: ['id', 'email', 'full_name'],
        where: { role: 'SUPER_ADMIN' },
        required: false,
      },
    ],
    order: [['created_at', 'DESC']],
  });
};

export const getClientById = async (clientId) => {
  const client = await Organization.findByPk(clientId, {
    include: [
      {
        model: ClientSubscription,
        include: [SubscriptionPlan],
      },
      {
        model: User,
        attributes: ['id', 'email', 'full_name', 'role'],
      },
    ],
  });

  if (!client) {
    throw new Error('Client not found');
  }

  return client;
};

export const updateClient = async (clientId, updateData) => {
  const client = await Organization.findByPk(clientId);
  if (!client) {
    throw new Error('Client not found');
  }

  return await client.update(updateData);
};

export const deactivateClient = async (clientId, reason) => {
  const client = await Organization.findByPk(clientId);
  if (!client) {
    throw new Error('Client not found');
  }

  // Update organization status
  await client.update({ status: 'inactive' });

  // Cancel active subscription
  const subscription = await ClientSubscription.findOne({
    where: {
      organization_id: clientId,
      status: 'active',
    },
  });

  if (subscription) {
    await subscription.update({
      status: 'cancelled',
      cancelled_at: new Date(),
      cancelled_reason: reason || 'Admin deactivation',
    });

    // Log to history
    await SubscriptionHistory.create({
      organization_id: clientId,
      client_subscription_id: subscription.id,
      event_type: 'subscription_cancelled',
      triggered_by: 'admin_action',
      notes: reason || 'Admin deactivation',
    });
  }

  return client;
};

// ============ SUBSCRIPTION MANAGEMENT ============

export const getClientSubscription = async (clientId) => {
  return await ClientSubscription.findOne({
    where: {
      organization_id: clientId,
      status: { [Op.in]: ['trial', 'active'] },
    },
    include: [SubscriptionPlan],
  });
};

export const createClientSubscription = async (clientId, planId, billingEmail) => {
  const plan = await SubscriptionPlan.findByPk(planId);
  if (!plan) {
    throw new Error('Plan not found');
  }

  const client = await Organization.findByPk(clientId);
  if (!client) {
    throw new Error('Client not found');
  }

  // Calculate trial end date
  const now = new Date();
  const trialEndDate = new Date(now.getTime() + plan.trial_days * 24 * 60 * 60 * 1000);
  const periodEndDate = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000); // 30 days

  const subscription = await ClientSubscription.create({
    organization_id: clientId,
    subscription_plan_id: planId,
    status: 'trial',
    billing_email: billingEmail || client.email,
    current_period_start: now,
    current_period_end: periodEndDate,
    trial_end_date: trialEndDate,
  });

  // Update organization with enabled modules
  await client.update({
    enabled_modules: plan.enabled_modules,
  });

  // Log to history
  await SubscriptionHistory.create({
    organization_id: clientId,
    client_subscription_id: subscription.id,
    event_type: 'subscription_created',
    new_plan_id: planId,
    triggered_by: 'admin_action',
    notes: `Subscription created for plan: ${plan.display_name}`,
  });

  return subscription;
};

export const upgradePlan = async (clientId, newPlanId, superAdminId) => {
  const subscription = await ClientSubscription.findOne({
    where: {
      organization_id: clientId,
      status: { [Op.in]: ['trial', 'active'] },
    },
    include: [SubscriptionPlan],
  });

  if (!subscription) {
    throw new Error('No active subscription found');
  }

  const newPlan = await SubscriptionPlan.findByPk(newPlanId);
  if (!newPlan) {
    throw new Error('New plan not found');
  }

  const oldPlanId = subscription.subscription_plan_id;

  // Calculate prorated amount (simple: just track upgrade)
  const proratedAmount = newPlan.price - subscription.SubscriptionPlan.price;

  // Update subscription
  await subscription.update({
    subscription_plan_id: newPlanId,
    current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
  });

  // Update organization modules
  const client = await Organization.findByPk(clientId);
  await client.update({
    enabled_modules: newPlan.enabled_modules,
  });

  // Log to history
  await SubscriptionHistory.create({
    organization_id: clientId,
    client_subscription_id: subscription.id,
    event_type: 'subscription_upgraded',
    old_plan_id: oldPlanId,
    new_plan_id: newPlanId,
    amount: proratedAmount,
    triggered_by: superAdminId,
    notes: `Upgraded from ${subscription.SubscriptionPlan.display_name} to ${newPlan.display_name}`,
  });

  return subscription;
};

export const toggleModule = async (clientId, moduleName, enable, superAdminId) => {
  const subscription = await ClientSubscription.findOne({
    where: {
      organization_id: clientId,
      status: { [Op.in]: ['trial', 'active'] },
    },
    include: [SubscriptionPlan],
  });

  if (!subscription) {
    throw new Error('No active subscription found');
  }

  const client = await Organization.findByPk(clientId);
  let enabledModules = client.enabled_modules || [];

  if (enable) {
    if (!enabledModules.includes(moduleName)) {
      enabledModules.push(moduleName);
    }
  } else {
    enabledModules = enabledModules.filter(m => m !== moduleName);
  }

  await client.update({ enabled_modules: enabledModules });

  // Log to history
  const eventType = enable ? 'module_enabled' : 'module_disabled';
  await SubscriptionHistory.create({
    organization_id: clientId,
    client_subscription_id: subscription.id,
    event_type: eventType,
    triggered_by: superAdminId,
    notes: `Module '${moduleName}' ${enable ? 'enabled' : 'disabled'} by admin`,
  });

  return { client, enabledModules };
};

// ============ ADMIN DASHBOARD ============

export const getAdminDashboard = async () => {
  const totalClients = await Organization.count();
  
  const activeSubscriptions = await ClientSubscription.count({
    where: { status: 'active' },
  });

  const trialSubscriptions = await ClientSubscription.count({
    where: { status: 'trial' },
  });

  const totalRevenue = await ClientSubscription.findAll({
    where: { status: 'active' },
    include: [
      {
        model: SubscriptionPlan,
        attributes: ['price'],
      },
    ],
    raw: true,
  }).then(subs => {
    return subs.reduce((sum, sub) => {
      return sum + (sub['SubscriptionPlan.price'] || 0);
    }, 0);
  });

  // Revenue by plan
  const revenueByPlan = await ClientSubscription.findAll({
    where: { status: 'active' },
    include: [
      {
        model: SubscriptionPlan,
        attributes: ['display_name', 'price'],
      },
    ],
    attributes: ['subscription_plan_id'],
    raw: true,
    group: ['subscription_plan_id'],
  });

  // Subscriptions by status
  const subscriptionsByStatus = await ClientSubscription.findAll({
    attributes: [
      'status',
      [require('sequelize').fn('COUNT', require('sequelize').col('id')), 'count'],
    ],
    group: ['status'],
    raw: true,
  });

  return {
    totalClients,
    activeSubscriptions,
    trialSubscriptions,
    totalRevenue: parseFloat(totalRevenue),
    mrr: parseFloat(totalRevenue), // Monthly Recurring Revenue
    subscriptionsByStatus: Object.fromEntries(
      subscriptionsByStatus.map(s => [s.status, s.count])
    ),
  };
};

export const getRevenueStats = async (period = 'monthly') => {
  const stats = await ClientSubscription.findAll({
    where: { status: 'active' },
    include: [
      {
        model: SubscriptionPlan,
        attributes: ['display_name', 'price', 'billing_cycle'],
      },
      {
        model: Organization,
        attributes: ['name'],
      },
    ],
    order: [['created_at', 'DESC']],
  });

  const totalByPlan = {};
  stats.forEach(sub => {
    const planName = sub.SubscriptionPlan.display_name;
    if (!totalByPlan[planName]) {
      totalByPlan[planName] = { count: 0, revenue: 0 };
    }
    totalByPlan[planName].count += 1;
    totalByPlan[planName].revenue += parseFloat(sub.SubscriptionPlan.price);
  });

  return {
    period,
    totalMRR: stats.reduce((sum, s) => sum + parseFloat(s.SubscriptionPlan.price), 0),
    revenueByPlan: totalByPlan,
    totalActiveSubscriptions: stats.length,
    clientsWithSubscriptions: new Set(stats.map(s => s.organization_id)).size,
  };
};

export const getSubscriptionHistory = async (clientId) => {
  return await SubscriptionHistory.findAll({
    where: { organization_id: clientId },
    order: [['created_at', 'DESC']],
    limit: 50,
  });
};

export default {
  getAllPlans,
  getPlanById,
  createPlan,
  updatePlan,
  deactivatePlan,
  getAllClients,
  getClientById,
  updateClient,
  deactivateClient,
  getClientSubscription,
  createClientSubscription,
  upgradePlan,
  toggleModule,
  getAdminDashboard,
  getRevenueStats,
  getSubscriptionHistory,
};
