import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import Role from '../models/Role.js';

// Verify JWT token
export const verifyToken = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];

    if (!token) {
      return res.status(401).json({
        success: false,
        error: 'No token provided',
      });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    const user = await User.findByPk(decoded.id);
    if (!user) {
      return res.status(401).json({
        success: false,
        error: 'User not found',
      });
    }

    req.user = user;
    next();
  } catch (error) {
    return res.status(401).json({
      success: false,
      error: 'Invalid token',
    });
  }
};

// Check if user has specific role(s)
export const checkRoleAccess = (requiredRoles) => {
  return async (req, res, next) => {
    try {
      if (!req.user) {
        return res.status(401).json({
          success: false,
          error: 'User not authenticated',
        });
      }

      const rolesArray = Array.isArray(requiredRoles) ? requiredRoles : [requiredRoles];

      // Check if user's role is in required roles
      if (!rolesArray.includes(req.user.role)) {
        return res.status(403).json({
          success: false,
          error: `Access denied. Required role(s): ${rolesArray.join(', ')}`,
        });
      }

      next();
    } catch (error) {
      return res.status(500).json({
        success: false,
        error: error.message,
      });
    }
  };
};

// Check module access for regular users
export const checkModuleAccess = (moduleName) => {
  return async (req, res, next) => {
    try {
      if (!req.user) {
        return res.status(401).json({
          success: false,
          error: 'User not authenticated',
        });
      }

      // Super admins always have access
      if (req.user.role === 'SUPER_ADMIN') {
        return next();
      }

      const organization = await sequelize.models.Organization.findByPk(req.user.organizationId);
      
      if (!organization) {
        return res.status(404).json({
          success: false,
          error: 'Organization not found',
        });
      }

      if (!organization.enabled_modules || !organization.enabled_modules.includes(moduleName)) {
        return res.status(403).json({
          success: false,
          error: `Module '${moduleName}' is not enabled for your organization`,
        });
      }

      next();
    } catch (error) {
      return res.status(500).json({
        success: false,
        error: error.message,
      });
    }
  };
};

// Check if user owns the resource or is admin
export const checkOwnershipOrAdmin = (resourceOwnerId) => {
  return async (req, res, next) => {
    try {
      if (!req.user) {
        return res.status(401).json({
          success: false,
          error: 'User not authenticated',
        });
      }

      // Super admin or resource owner can access
      if (req.user.role === 'SUPER_ADMIN' || req.user.id === resourceOwnerId) {
        return next();
      }

      return res.status(403).json({
        success: false,
        error: 'Access denied. You do not own this resource',
      });
    } catch (error) {
      return res.status(500).json({
        success: false,
        error: error.message,
      });
    }
  };
};

export default {
  verifyToken,
  checkRoleAccess,
  checkModuleAccess,
  checkOwnershipOrAdmin,
};
