import express from 'express';
import * as adminController from './admin.controller.js';
import { checkRoleAccess } from '../middleware/authMiddleware.js';

const router = express.Router();

// Middleware: Only SUPER_ADMIN can access admin routes
router.use(checkRoleAccess('SUPER_ADMIN'));

// ============ SUBSCRIPTION PLANS ============

/**
 * GET /api/admin/plans
 * Get all active subscription plans
 */
router.get('/plans', adminController.getAllPlans);

/**
 * GET /api/admin/plans/:planId
 * Get a specific subscription plan
 */
router.get('/plans/:planId', adminController.getPlanById);

/**
 * POST /api/admin/plans
 * Create a new subscription plan
 * Body: { name, display_name, description, price, billing_cycle, max_users, max_properties, enabled_modules, features, trial_days }
 */
router.post('/plans', adminController.createPlan);

/**
 * PUT /api/admin/plans/:planId
 * Update a subscription plan
 */
router.put('/plans/:planId', adminController.updatePlan);

/**
 * DELETE /api/admin/plans/:planId
 * Deactivate a subscription plan
 */
router.delete('/plans/:planId', adminController.deactivatePlan);

// ============ CLIENT MANAGEMENT ============

/**
 * GET /api/admin/clients
 * Get all clients
 * Query: ?status=active&search=hotel
 */
router.get('/clients', adminController.getAllClients);

/**
 * GET /api/admin/clients/:clientId
 * Get a specific client with subscription details
 */
router.get('/clients/:clientId', adminController.getClientById);

/**
 * PUT /api/admin/clients/:clientId
 * Update client details
 * Body: { name, email, phone, address, city, state, country, contact_person, website }
 */
router.put('/clients/:clientId', adminController.updateClient);

/**
 * POST /api/admin/clients/:clientId/deactivate
 * Deactivate a client and cancel subscription
 * Body: { reason }
 */
router.post('/clients/:clientId/deactivate', adminController.deactivateClient);

// ============ SUBSCRIPTION MANAGEMENT ============

/**
 * GET /api/admin/clients/:clientId/subscription
 * Get client's active subscription
 */
router.get('/clients/:clientId/subscription', adminController.getClientSubscription);

/**
 * POST /api/admin/clients/:clientId/subscription
 * Create a new subscription for a client
 * Body: { planId, billingEmail }
 */
router.post('/clients/:clientId/subscription', adminController.createClientSubscription);

/**
 * POST /api/admin/clients/:clientId/subscription/upgrade
 * Upgrade client's subscription plan
 * Body: { newPlanId }
 */
router.post('/clients/:clientId/subscription/upgrade', adminController.upgradePlan);

/**
 * POST /api/admin/clients/:clientId/modules/toggle
 * Enable/Disable a specific module for a client
 * Body: { moduleName, enable: boolean }
 */
router.post('/clients/:clientId/modules/toggle', adminController.toggleModule);

/**
 * GET /api/admin/clients/:clientId/subscription/history
 * Get subscription change history for a client
 */
router.get('/clients/:clientId/subscription/history', adminController.getSubscriptionHistory);

// ============ ADMIN DASHBOARD ============

/**
 * GET /api/admin/dashboard
 * Get admin dashboard with key metrics:
 * - Total clients, active subscriptions, trial subscriptions
 * - Total revenue, MRR, subscriptions by status
 */
router.get('/dashboard', adminController.getAdminDashboard);

/**
 * GET /api/admin/revenue
 * Get revenue analytics
 * Query: ?period=monthly
 */
router.get('/revenue', adminController.getRevenueStats);

export default router;
