#!/bin/bash

echo "🚀 Setting up Phase 2 - Dashboard Module..."
echo ""

# Step 1: Create directory if not exists
echo "📁 Creating directory structure..."
mkdir -p backend/src/routes/02_dashboard

# Step 2: Copy files
echo "📋 Copying dashboard files..."
cp hotelpro-phase2/backend/src/routes/02_dashboard/* backend/src/routes/02_dashboard/

# Step 3: Update server.js to mount dashboard routes
echo "🔧 Updating server.js..."

# Check if dashboard route already mounted
if grep -q "dashboardRoutes" backend/src/server.js; then
  echo "ℹ️  Dashboard routes already mounted"
else
  # Add import statement after other route imports
  sed -i "/import.*routes from/a import dashboardRoutes from './routes/02_dashboard/dashboard.routes.js';" backend/src/server.js
  
  # Add route mounting after other routes
  sed -i "/app.use.*auth.*routes/a app.use('/api/dashboard', dashboardRoutes);" backend/src/server.js
  
  echo "✅ server.js updated with dashboard routes"
fi

# Step 4: Verify files
echo ""
echo "✅ Files in place:"
ls -la backend/src/routes/02_dashboard/

# Step 5: Git operations
echo ""
echo "📤 Committing to GitHub..."
git add .
git commit -m "Phase 2: Dashboard module - Occupancy, Revenue, Guest metrics" -q

echo "📤 Pushing to GitHub..."
git push origin main -q

echo ""
echo "========================================="
echo "✅ PHASE 2 SETUP COMPLETE!"
echo "========================================="
echo ""
echo "✅ 4 new files added:"
echo "   - dashboard.service.js"
echo "   - dashboard.controller.js"
echo "   - dashboard.routes.js"
echo "   - dashboard.validators.js"
echo ""
echo "✅ server.js updated with routes"
echo "✅ Pushed to GitHub"
echo ""
echo "🚀 Endpoints ready:"
echo "   GET /api/dashboard/master"
echo "   GET /api/dashboard/occupancy"
echo "   GET /api/dashboard/revenue"
echo "   GET /api/dashboard/arrivals"
echo "   GET /api/dashboard/departures"
echo "   GET /api/dashboard/payments"
echo "   GET /api/dashboard/room-status"
echo ""
echo "Ready for Phase 3! 🎉"
