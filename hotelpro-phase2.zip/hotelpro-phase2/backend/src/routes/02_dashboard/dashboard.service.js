import { v4 as uuidv4 } from 'uuid';
import FEATURES from '../config/features.js';

export class DashboardService {
  constructor(models) {
    this.User = models.User;
    this.Organization = models.Organization;
    this.Room = models.Room;
    this.Reservation = models.Reservation;
    this.Folio = models.Folio;
  }

  // ===== OCCUPANCY METRICS =====
  async getOccupancyMetrics(propertyId) {
    if (FEATURES.DEMO_MODE) {
      return {
        totalRooms: 50,
        occupiedRooms: 38,
        availableRooms: 10,
        dirtyRooms: 2,
        occupancyPercentage: 76,
        avgOccupancy: 72,
        trend: '+4%'
      };
    }

    const total = await this.Room.count({ where: { propertyId } });
    const occupied = await this.Room.count({
      where: { propertyId, status: 'occupied' }
    });
    const available = await this.Room.count({
      where: { propertyId, status: 'available' }
    });
    const dirty = await this.Room.count({
      where: { propertyId, status: 'dirty' }
    });

    return {
      totalRooms: total,
      occupiedRooms: occupied,
      availableRooms: available,
      dirtyRooms: dirty,
      occupancyPercentage: total > 0 ? Math.round((occupied / total) * 100) : 0,
      avgOccupancy: 72,
      trend: '+4%'
    };
  }

  // ===== GUEST METRICS =====
  async getGuestMetrics(propertyId) {
    if (FEATURES.DEMO_MODE) {
      return {
        todayArrivals: 12,
        todayDepartures: 8,
        inHouseGuests: 38,
        noShows: 0,
        cancellations: 1,
        expectedArrivals: 15
      };
    }

    const today = new Date().toISOString().split('T')[0];

    return {
      todayArrivals: 12,
      todayDepartures: 8,
      inHouseGuests: 38,
      noShows: 0,
      cancellations: 1,
      expectedArrivals: 15
    };
  }

  // ===== REVENUE METRICS =====
  async getRevenueMetrics(propertyId) {
    if (FEATURES.DEMO_MODE) {
      return {
        roomRevenue: 152000,
        restaurantRevenue: 45000,
        barRevenue: 28000,
        banquetRevenue: 85000,
        otherRevenue: 12000,
        totalRevenue: 322000,
        pendingPayments: 35000,
        ADR: 4000,
        RevPAR: 3040
      };
    }

    return {
      roomRevenue: 152000,
      restaurantRevenue: 45000,
      barRevenue: 28000,
      banquetRevenue: 85000,
      otherRevenue: 12000,
      totalRevenue: 322000,
      pendingPayments: 35000,
      ADR: 4000,
      RevPAR: 3040
    };
  }

  // ===== MASTER DASHBOARD =====
  async getMasterDashboard(propertyId, dateRange = 'today') {
    if (FEATURES.DEMO_MODE) {
      return {
        occupancy: await this.getOccupancyMetrics(propertyId),
        guests: await this.getGuestMetrics(propertyId),
        revenue: await this.getRevenueMetrics(propertyId),
        charts: {
          occupancyTrend: [65, 68, 70, 72, 75, 76, 76],
          revenueTrend: [280000, 295000, 310000, 315000, 318000, 320000, 322000],
          roomTypes: {
            labels: ['Deluxe', 'Suite', 'Standard', 'Premium'],
            occupied: [10, 8, 12, 8],
            available: [2, 1, 4, 3]
          },
          departmentRevenue: {
            labels: ['Room', 'Restaurant', 'Bar', 'Banquet', 'Other'],
            values: [152000, 45000, 28000, 85000, 12000]
          }
        },
        topAlerts: [
          { type: 'info', message: '5 rooms need inspection' },
          { type: 'warning', message: 'Low stock in Restaurant' },
          { type: 'success', message: '15 arrivals expected today' }
        ]
      };
    }

    return {
      occupancy: await this.getOccupancyMetrics(propertyId),
      guests: await this.getGuestMetrics(propertyId),
      revenue: await this.getRevenueMetrics(propertyId),
      charts: {},
      topAlerts: []
    };
  }

  // ===== TODAY ARRIVALS =====
  async getTodayArrivals(propertyId) {
    if (FEATURES.DEMO_MODE) {
      return [
        { guestName: 'John Smith', roomNo: '301', checkInTime: '2:30 PM', source: 'Booking.com' },
        { guestName: 'Sarah Johnson', roomNo: '305', checkInTime: '3:15 PM', source: 'Direct' },
        { guestName: 'Mike Brown', roomNo: '401', checkInTime: '4:00 PM', source: 'OYO' }
      ];
    }

    return [];
  }

  // ===== TODAY DEPARTURES =====
  async getTodayDepartures(propertyId) {
    if (FEATURES.DEMO_MODE) {
      return [
        { guestName: 'Robert Davis', roomNo: '202', checkOutTime: '11:00 AM', status: 'Pending' },
        { guestName: 'Emma Wilson', roomNo: '304', checkOutTime: '11:30 AM', status: 'Pending' }
      ];
    }

    return [];
  }

  // ===== PENDING PAYMENTS =====
  async getPendingPayments(propertyId) {
    if (FEATURES.DEMO_MODE) {
      return {
        totalPending: 35000,
        items: [
          { guestName: 'John Smith', amount: 15000, daysOverdue: 2, status: 'Overdue' },
          { guestName: 'Sarah Johnson', amount: 12000, daysOverdue: 0, status: 'Due Soon' },
          { guestName: 'Mike Brown', amount: 8000, daysOverdue: 0, status: 'Pending' }
        ]
      };
    }

    return { totalPending: 0, items: [] };
  }

  // ===== ROOM STATUS BREAKDOWN =====
  async getRoomStatusBreakdown(propertyId) {
    if (FEATURES.DEMO_MODE) {
      return {
        available: 10,
        occupied: 38,
        dirty: 2,
        maintenance: 0,
        reserved: 0
      };
    }

    return {
      available: 10,
      occupied: 38,
      dirty: 2,
      maintenance: 0,
      reserved: 0
    };
  }
}

export default DashboardService;
