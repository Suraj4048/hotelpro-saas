export const dashboardValidators = {
  dateRange: (value) => {
    const validRanges = ['today', 'week', 'month', 'year', 'custom'];
    if (!validRanges.includes(value)) {
      throw new Error(`Invalid date range. Must be one of: ${validRanges.join(', ')}`);
    }
    return true;
  },

  propertyId: (value) => {
    if (!value || typeof value !== 'string') {
      throw new Error('Property ID must be a valid UUID');
    }
    return true;
  }
};

export default dashboardValidators;
