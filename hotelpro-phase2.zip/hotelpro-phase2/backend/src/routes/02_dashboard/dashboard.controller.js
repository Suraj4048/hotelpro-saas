import { ApiError } from '../middleware/errorHandler.js';
import { asyncHandler } from '../middleware/errorHandler.js';
import FEATURES from '../config/features.js';

export class DashboardController {
  constructor(dashboardService) {
    this.dashboardService = dashboardService;
  }

  getMasterDashboard = asyncHandler(async (req, res) => {
    const propertyId = req.user.propertyId;
    const { dateRange } = req.query;

    if (!propertyId) {
      throw new ApiError(400, 'Property ID is required');
    }

    const dashboard = await this.dashboardService.getMasterDashboard(
      propertyId,
      dateRange || 'today'
    );

    res.status(200).json({
      success: true,
      data: dashboard,
      devMode: FEATURES.DEMO_MODE
    });
  });

  getOccupancy = asyncHandler(async (req, res) => {
    const propertyId = req.user.propertyId;

    const occupancy = await this.dashboardService.getOccupancyMetrics(propertyId);

    res.status(200).json({
      success: true,
      data: occupancy,
      devMode: FEATURES.DEMO_MODE
    });
  });

  getGuests = asyncHandler(async (req, res) => {
    const propertyId = req.user.propertyId;

    const guests = await this.dashboardService.getGuestMetrics(propertyId);

    res.status(200).json({
      success: true,
      data: guests,
      devMode: FEATURES.DEMO_MODE
    });
  });

  getRevenue = asyncHandler(async (req, res) => {
    const propertyId = req.user.propertyId;

    const revenue = await this.dashboardService.getRevenueMetrics(propertyId);

    res.status(200).json({
      success: true,
      data: revenue,
      devMode: FEATURES.DEMO_MODE
    });
  });

  getTodayArrivals = asyncHandler(async (req, res) => {
    const propertyId = req.user.propertyId;

    const arrivals = await this.dashboardService.getTodayArrivals(propertyId);

    res.status(200).json({
      success: true,
      data: arrivals,
      devMode: FEATURES.DEMO_MODE
    });
  });

  getTodayDepartures = asyncHandler(async (req, res) => {
    const propertyId = req.user.propertyId;

    const departures = await this.dashboardService.getTodayDepartures(propertyId);

    res.status(200).json({
      success: true,
      data: departures,
      devMode: FEATURES.DEMO_MODE
    });
  });

  getPendingPayments = asyncHandler(async (req, res) => {
    const propertyId = req.user.propertyId;

    const payments = await this.dashboardService.getPendingPayments(propertyId);

    res.status(200).json({
      success: true,
      data: payments,
      devMode: FEATURES.DEMO_MODE
    });
  });

  getRoomStatus = asyncHandler(async (req, res) => {
    const propertyId = req.user.propertyId;

    const roomStatus = await this.dashboardService.getRoomStatusBreakdown(propertyId);

    res.status(200).json({
      success: true,
      data: roomStatus,
      devMode: FEATURES.DEMO_MODE
    });
  });
}

export default DashboardController;
