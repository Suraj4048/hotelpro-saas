import { Router } from 'express';
import DashboardController from './dashboard.controller.js';
import DashboardService from './dashboard.service.js';
import { verifyToken } from '../../middleware/auth.js';

const router = Router();

// Initialize service and controller
const dashboardService = new DashboardService(models);
const dashboardController = new DashboardController(dashboardService);

// All routes require authentication
router.use(verifyToken);

// Dashboard endpoints
router.get('/master', dashboardController.getMasterDashboard);
router.get('/occupancy', dashboardController.getOccupancy);
router.get('/guests', dashboardController.getGuests);
router.get('/revenue', dashboardController.getRevenue);
router.get('/arrivals', dashboardController.getTodayArrivals);
router.get('/departures', dashboardController.getTodayDepartures);
router.get('/payments', dashboardController.getPendingPayments);
router.get('/room-status', dashboardController.getRoomStatus);

export default router;
