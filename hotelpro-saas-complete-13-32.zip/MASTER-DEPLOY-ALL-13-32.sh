#!/bin/bash
set -e

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║   🚀 HOTELPRO SAAS - PHASES 13-32 MASTER DEPLOYMENT          ║"
echo "║              COMPLETE SYSTEM - ALL-IN-ONE                    ║"
echo "║     Integrations + Frontend + 20 Additional Modules          ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

PROJECT_DIR="/workspaces/hotelpro-saas"
cd $PROJECT_DIR

echo "📍 Working directory: $PROJECT_DIR"
echo ""

# Phases 13-14 (Core)
bash deploy-phase13.sh && echo "✅ Phase 13 done" && sleep 1
bash deploy-phase14.sh && echo "✅ Phase 14 done" && sleep 1

# Phases 15-16 (Club & Kitty)
bash deploy-phase15.sh && echo "✅ Phase 15 done" && sleep 1
bash deploy-phase16.sh && echo "✅ Phase 16 done" && sleep 1

# Phases 17-24 (Bundle)
bash deploy-phases-17-28-bundle.sh && echo "✅ Phases 17-24 done" && sleep 1

# Phase 25 (Search)
bash deploy-phase25.sh && echo "✅ Phase 25 done" && sleep 1

# Phases 26-28 (Apps)
bash deploy-phases-26-28.sh && echo "✅ Phases 26-28 done" && sleep 1

# Phases 29-32 (Missing Modules)
bash deploy-phase29.sh && echo "✅ Phase 29 done" && sleep 1
bash deploy-phase30.sh && echo "✅ Phase 30 done" && sleep 1
bash deploy-phase31.sh && echo "✅ Phase 31 done" && sleep 1
bash deploy-phase32.sh && echo "✅ Phase 32 done" && sleep 1

echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║    🎉 ALL PHASES 13-32 DEPLOYMENT COMPLETE!                  ║"
echo "║           COMPLETE HOTEL MANAGEMENT SYSTEM READY              ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""
echo "✅ DEPLOYED:"
echo "   Phase 13: Integrations (Razorpay, Stripe, Twilio, SendGrid)"
echo "   Phase 14: Frontend React UI (Vite, Tailwind, Recharts)"
echo "   Phase 15: Club Management"
echo "   Phase 16: Kitty & Party Hall"
echo "   Phase 17: Spa & Salon"
echo "   Phase 18: Gym & Pool"
echo "   Phase 19: Parking"
echo "   Phase 20: Travel Desk"
echo "   Phase 21: Maintenance"
echo "   Phase 22: Security"
echo "   Phase 23: CRM & Sales"
echo "   Phase 24: Loyalty Program"
echo "   Phase 25: Global Search & Audit"
echo "   Phase 26: Guest Mobile App"
echo "   Phase 27: Staff Apps Suite"
echo "   Phase 28: Settings & Customization"
echo "   Phase 29: Food Delivery Integration (Zomato, Swiggy, ONDC)"
echo "   Phase 30: OTA Channel Manager (Booking.com, Airbnb, Expedia)"
echo "   Phase 31: Multi-property Architecture"
echo "   Phase 32: Command Palette & Advanced UI"
echo ""
echo "📊 TOTALS:"
echo "   Total Phases: 20 (13-32)"
echo "   Total New Modules: 20"
echo "   Total Models: 50+"
echo "   Total Endpoints: 120+"
echo "   Database Tables: Auto-created"
echo ""
echo "✨ FEATURES:"
echo "   ✅ Multi-tenant ready"
echo "   ✅ JWT authenticated"
echo "   ✅ Database indexed"
echo "   ✅ Frontend complete"
echo "   ✅ All integrations"
echo "   ✅ Multi-property support"
echo "   ✅ Command palette"
echo "   ✅ OTA channel manager"
echo "   ✅ Food delivery sync"
echo ""
echo "🎯 NEXT STEPS:"
echo "   1. npm start (from backend)"
echo "   2. cd frontend && npm run dev"
echo "   3. Open http://localhost:3000"
echo "   4. Login: demo@hotelpro.com / demo123"
echo ""
echo "═══════════════════════════════════════════════════════════════════"
echo "✅ Complete hotel system deployed successfully!"
echo "═══════════════════════════════════════════════════════════════════"
