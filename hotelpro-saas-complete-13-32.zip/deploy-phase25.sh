#!/bin/bash
set -e
PROJECT_DIR="/workspaces/hotelpro-saas"
cd $PROJECT_DIR

echo "🔍 PHASE 25: Global Search & Advanced Features"
mkdir -p backend/src/models/25_search backend/src/routes/25_search

cat > backend/src/models/25_search/SearchIndex.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const SearchIndex = sequelize.define('SearchIndex', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false },
  entityType: { type: DataTypes.ENUM('room', 'guest', 'reservation', 'bill', 'staff', 'vendor', 'event'), defaultValue: 'room' },
  entityId: { type: DataTypes.UUID },
  searchableText: { type: DataTypes.TEXT },
  keywords: { type: DataTypes.JSON },
  lastUpdated: { type: DataTypes.DATE, defaultValue: DataTypes.NOW }
}, { tableName: 'search_index', timestamps: true, indexes: [{ fields: ['organizationId', 'searchableText'] }] });

export default SearchIndex;
EOF

cat > backend/src/models/25_search/AuditLog.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const AuditLog = sequelize.define('AuditLog', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false },
  userId: { type: DataTypes.UUID },
  action: { type: DataTypes.STRING },
  module: { type: DataTypes.STRING },
  entityType: { type: DataTypes.STRING },
  entityId: { type: DataTypes.UUID },
  changes: { type: DataTypes.JSON },
  ipAddress: { type: DataTypes.STRING },
  timestamp: { type: DataTypes.DATE, defaultValue: DataTypes.NOW }
}, { tableName: 'audit_logs', timestamps: true, indexes: [{ fields: ['organizationId', 'timestamp'] }] });

export default AuditLog;
EOF

cat > backend/src/models/25_search/Notification.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const Notification = sequelize.define('Notification', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false },
  userId: { type: DataTypes.UUID },
  type: { type: DataTypes.ENUM('booking', 'payment', 'maintenance', 'guest_checkin', 'alert'), defaultValue: 'alert' },
  title: { type: DataTypes.STRING },
  message: { type: DataTypes.TEXT },
  isRead: { type: DataTypes.BOOLEAN, defaultValue: false },
  link: { type: DataTypes.STRING }
}, { tableName: 'notifications', timestamps: true, indexes: [{ fields: ['organizationId', 'userId', 'isRead'] }] });

export default Notification;
EOF

cat > backend/src/routes/25_search/search.service.js << 'EOF'
import SearchIndex from '../../models/25_search/SearchIndex.js';
import AuditLog from '../../models/25_search/AuditLog.js';
import Notification from '../../models/25_search/Notification.js';
import { Op } from 'sequelize';

export const globalSearch = async (organizationId, query) => {
  return await SearchIndex.findAll({
    where: {
      organizationId,
      [Op.or]: [
        { searchableText: { [Op.like]: `%${query}%` } },
        sequelize.literal(`JSON_CONTAINS(keywords, JSON_QUOTE('${query}'))`)
      ]
    },
    limit: 20
  });
};

export const createAuditLog = async (organizationId, data) => {
  return await AuditLog.create({ organizationId, timestamp: new Date(), ...data });
};

export const getAuditLogs = async (organizationId, filters = {}) => {
  const where = { organizationId };
  if (filters.module) where.module = filters.module;
  if (filters.userId) where.userId = filters.userId;
  return await AuditLog.findAll({ where, order: [['timestamp', 'DESC']], limit: 100 });
};

export const createNotification = async (organizationId, data) => {
  return await Notification.create({ organizationId, ...data });
};

export const getNotifications = async (organizationId, userId, unreadOnly = false) => {
  const where = { organizationId, userId };
  if (unreadOnly) where.isRead = false;
  return await Notification.findAll({ where, order: [['createdAt', 'DESC']], limit: 50 });
};

export const markNotificationRead = async (id) => {
  return await Notification.update({ isRead: true }, { where: { id } });
};
EOF

cat > backend/src/routes/25_search/search.routes.js << 'EOF'
import express from 'express';
import { authenticate } from '../../middleware/auth.middleware.js';
import * as service from './search.service.js';

const router = express.Router();
router.use(authenticate);

router.get('/global', async (req, res) => {
  try {
    if (!req.query.q) return res.status(400).json({ success: false, message: 'Query required' });
    const results = await service.globalSearch(req.user.organizationId, req.query.q);
    res.json({ success: true, data: results });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.get('/audit-logs', async (req, res) => {
  try {
    const data = await service.getAuditLogs(req.user.organizationId, req.query);
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.get('/notifications', async (req, res) => {
  try {
    const data = await service.getNotifications(req.user.organizationId, req.user.id, req.query.unread === 'true');
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.put('/notifications/:id/read', async (req, res) => {
  try {
    await service.markNotificationRead(req.params.id);
    res.json({ success: true, message: 'Marked as read' });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

export default router;
EOF

sed -i "/import loyaltyRoutes/a import searchRoutes from './routes/25_search/search.routes.js';" backend/src/server.js
sed -i "/app.use('\/api\/loyalty'/a app.use('/api/search', searchRoutes);" backend/src/server.js

cat > backend/src/sync/sync-phase25.js << 'EOF'
import SearchIndex from '../models/25_search/SearchIndex.js';
import AuditLog from '../models/25_search/AuditLog.js';
import Notification from '../models/25_search/Notification.js';

const sync = async () => {
  try {
    console.log('🔄 Syncing Phase 25...');
    await Promise.all([
      SearchIndex.sync({ alter: true }),
      AuditLog.sync({ alter: true }),
      Notification.sync({ alter: true })
    ]);
    console.log('✅ Phase 25 synced');
  } catch (error) {
    console.error('❌ Sync error:', error.message);
  }
};

sync();
EOF

node backend/src/sync/sync-phase25.js

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║         ✅ PHASE 25: Global Search COMPLETE                   ║"
echo "║        3 Models | 5 Endpoints | Ready for Upload              ║"
echo "╚════════════════════════════════════════════════════════════════╝"
