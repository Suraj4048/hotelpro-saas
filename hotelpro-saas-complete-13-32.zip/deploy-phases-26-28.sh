#!/bin/bash
set -e
PROJECT_DIR="/workspaces/hotelpro-saas"
cd $PROJECT_DIR

echo "📱 PHASE 26-28: Apps & Settings"
echo "================================"

# ============================================================================
# PHASE 26: GUEST MOBILE APP
# ============================================================================

echo "📲 PHASE 26: Guest Mobile App Backend"
mkdir -p backend/src/models/26_guest_app backend/src/routes/26_guest_app

cat > backend/src/models/26_guest_app/GuestProfile.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const GuestProfile = sequelize.define('GuestProfile', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false },
  guestId: { type: DataTypes.UUID },
  appVersion: { type: DataTypes.STRING },
  preferences: { type: DataTypes.JSON },
  pushTokens: { type: DataTypes.JSON },
  lastLogin: { type: DataTypes.DATE },
  isActive: { type: DataTypes.BOOLEAN, defaultValue: true }
}, { tableName: 'guest_profiles', timestamps: true });

export default GuestProfile;
EOF

cat > backend/src/models/26_guest_app/GuestRequest.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const GuestRequest = sequelize.define('GuestRequest', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false },
  guestId: { type: DataTypes.UUID },
  requestType: { type: DataTypes.ENUM('housekeeping', 'maintenance', 'food_delivery', 'concierge', 'other'), defaultValue: 'other' },
  title: { type: DataTypes.STRING },
  description: { type: DataTypes.TEXT },
  priority: { type: DataTypes.ENUM('low', 'medium', 'high', 'urgent'), defaultValue: 'medium' },
  status: { type: DataTypes.ENUM('pending', 'in_progress', 'completed'), defaultValue: 'pending' },
  rating: { type: DataTypes.INTEGER }
}, { tableName: 'guest_requests', timestamps: true, indexes: [{ fields: ['organizationId', 'status'] }] });

export default GuestRequest;
EOF

cat > backend/src/routes/26_guest_app/guest-app.routes.js << 'EOF'
import express from 'express';
import { authenticate } from '../../middleware/auth.middleware.js';
import GuestProfile from '../../models/26_guest_app/GuestProfile.js';
import GuestRequest from '../../models/26_guest_app/GuestRequest.js';

const router = express.Router();

router.post('/register', async (req, res) => {
  try {
    const data = await GuestProfile.create({ organizationId: req.body.organizationId, ...req.body });
    res.status(201).json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.use(authenticate);

router.get('/profile', async (req, res) => {
  try {
    const data = await GuestProfile.findOne({ where: { organizationId: req.user.organizationId, guestId: req.user.id } });
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.post('/requests', async (req, res) => {
  try {
    const data = await GuestRequest.create({ organizationId: req.user.organizationId, guestId: req.user.id, ...req.body });
    res.status(201).json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.get('/requests', async (req, res) => {
  try {
    const data = await GuestRequest.findAll({ where: { organizationId: req.user.organizationId, guestId: req.user.id }, order: [['createdAt', 'DESC']] });
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

export default router;
EOF

sed -i "/import searchRoutes/a import guestAppRoutes from './routes/26_guest_app/guest-app.routes.js';" backend/src/server.js
sed -i "/app.use('\/api\/search'/a app.use('/api/guest-app', guestAppRoutes);" backend/src/server.js

# ============================================================================
# PHASE 27: STAFF APPS SUITE
# ============================================================================

echo "👨‍💼 PHASE 27: Staff Apps Suite"
mkdir -p backend/src/models/27_staff_app backend/src/routes/27_staff_app

cat > backend/src/models/27_staff_app/StaffApp.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const StaffApp = sequelize.define('StaffApp', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false },
  staffId: { type: DataTypes.UUID },
  appType: { type: DataTypes.ENUM('housekeeping', 'restaurant', 'hr', 'maintenance'), defaultValue: 'housekeeping' },
  isAssigned: { type: DataTypes.BOOLEAN, defaultValue: true },
  permissions: { type: DataTypes.JSON }
}, { tableName: 'staff_apps', timestamps: true });

export default StaffApp;
EOF

cat > backend/src/models/27_staff_app/ShiftTracking.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const ShiftTracking = sequelize.define('ShiftTracking', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false },
  staffId: { type: DataTypes.UUID },
  checkInTime: { type: DataTypes.DATE },
  checkOutTime: { type: DataTypes.DATE },
  duration: { type: DataTypes.INTEGER, comment: 'in minutes' },
  status: { type: DataTypes.ENUM('checked_in', 'checked_out', 'on_leave'), defaultValue: 'checked_in' },
  location: { type: DataTypes.JSON }
}, { tableName: 'shift_tracking', timestamps: true, indexes: [{ fields: ['organizationId', 'checkInTime'] }] });

export default ShiftTracking;
EOF

cat > backend/src/routes/27_staff_app/staff-app.routes.js << 'EOF'
import express from 'express';
import { authenticate } from '../../middleware/auth.middleware.js';
import StaffApp from '../../models/27_staff_app/StaffApp.js';
import ShiftTracking from '../../models/27_staff_app/ShiftTracking.js';

const router = express.Router();
router.use(authenticate);

router.post('/assign', async (req, res) => {
  try {
    const data = await StaffApp.create({ organizationId: req.user.organizationId, ...req.body });
    res.status(201).json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.get('/assignments', async (req, res) => {
  try {
    const data = await StaffApp.findAll({ where: { organizationId: req.user.organizationId } });
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.post('/check-in', async (req, res) => {
  try {
    const data = await ShiftTracking.create({ organizationId: req.user.organizationId, staffId: req.user.id, checkInTime: new Date(), status: 'checked_in', ...req.body });
    res.status(201).json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.post('/check-out/:trackingId', async (req, res) => {
  try {
    const tracking = await ShiftTracking.findOne({ where: { id: req.params.trackingId, organizationId: req.user.organizationId } });
    if (!tracking) throw new Error('Tracking not found');
    const duration = Math.round((new Date() - tracking.checkInTime) / 60000);
    const data = await tracking.update({ checkOutTime: new Date(), status: 'checked_out', duration });
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.get('/shifts', async (req, res) => {
  try {
    const data = await ShiftTracking.findAll({ where: { organizationId: req.user.organizationId }, order: [['checkInTime', 'DESC']] });
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

export default router;
EOF

sed -i "/import guestAppRoutes/a import staffAppRoutes from './routes/27_staff_app/staff-app.routes.js';" backend/src/server.js
sed -i "/app.use('\/api\/guest-app'/a app.use('/api/staff-app', staffAppRoutes);" backend/src/server.js

# ============================================================================
# PHASE 28: SETTINGS & CUSTOMIZATION
# ============================================================================

echo "⚙️ PHASE 28: Settings & Customization"
mkdir -p backend/src/models/28_settings backend/src/routes/28_settings

cat > backend/src/models/28_settings/OrgSettings.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const OrgSettings = sequelize.define('OrgSettings', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false, unique: true },
  companyName: { type: DataTypes.STRING },
  companyLogo: { type: DataTypes.STRING },
  timezone: { type: DataTypes.STRING, defaultValue: 'Asia/Kolkata' },
  currency: { type: DataTypes.STRING, defaultValue: 'INR' },
  checkInTime: { type: DataTypes.TIME, defaultValue: '14:00' },
  checkOutTime: { type: DataTypes.TIME, defaultValue: '12:00' },
  theme: { type: DataTypes.ENUM('light', 'dark'), defaultValue: 'light' },
  emailNotifications: { type: DataTypes.BOOLEAN, defaultValue: true },
  smsNotifications: { type: DataTypes.BOOLEAN, defaultValue: true },
  customConfig: { type: DataTypes.JSON }
}, { tableName: 'org_settings', timestamps: true });

export default OrgSettings;
EOF

cat > backend/src/models/28_settings/UserPreferences.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const UserPreferences = sequelize.define('UserPreferences', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false },
  userId: { type: DataTypes.UUID },
  theme: { type: DataTypes.ENUM('light', 'dark', 'auto'), defaultValue: 'auto' },
  language: { type: DataTypes.STRING, defaultValue: 'en' },
  itemsPerPage: { type: DataTypes.INTEGER, defaultValue: 20 },
  dashboardLayout: { type: DataTypes.JSON },
  defaultView: { type: DataTypes.STRING, defaultValue: 'dashboard' }
}, { tableName: 'user_preferences', timestamps: true });

export default UserPreferences;
EOF

cat > backend/src/routes/28_settings/settings.routes.js << 'EOF'
import express from 'express';
import { authenticate } from '../../middleware/auth.middleware.js';
import OrgSettings from '../../models/28_settings/OrgSettings.js';
import UserPreferences from '../../models/28_settings/UserPreferences.js';

const router = express.Router();
router.use(authenticate);

router.get('/organization', async (req, res) => {
  try {
    const data = await OrgSettings.findOne({ where: { organizationId: req.user.organizationId } });
    if (!data) return res.status(404).json({ success: false, message: 'Settings not found' });
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.put('/organization', async (req, res) => {
  try {
    let settings = await OrgSettings.findOne({ where: { organizationId: req.user.organizationId } });
    if (!settings) {
      settings = await OrgSettings.create({ organizationId: req.user.organizationId, ...req.body });
    } else {
      await settings.update(req.body);
    }
    res.json({ success: true, data: settings });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.get('/user-preferences', async (req, res) => {
  try {
    const data = await UserPreferences.findOne({ where: { organizationId: req.user.organizationId, userId: req.user.id } });
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.put('/user-preferences', async (req, res) => {
  try {
    let prefs = await UserPreferences.findOne({ where: { organizationId: req.user.organizationId, userId: req.user.id } });
    if (!prefs) {
      prefs = await UserPreferences.create({ organizationId: req.user.organizationId, userId: req.user.id, ...req.body });
    } else {
      await prefs.update(req.body);
    }
    res.json({ success: true, data: prefs });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

export default router;
EOF

sed -i "/import staffAppRoutes/a import settingsRoutes from './routes/28_settings/settings.routes.js';" backend/src/server.js
sed -i "/app.use('\/api\/staff-app'/a app.use('/api/settings', settingsRoutes);" backend/src/server.js

# ============================================================================
# DATABASE SYNC
# ============================================================================

echo ""
echo "🔄 Syncing Phases 26-28 models..."

cat > backend/src/sync/sync-phases-26-28.js << 'EOF'
import GuestProfile from '../models/26_guest_app/GuestProfile.js';
import GuestRequest from '../models/26_guest_app/GuestRequest.js';
import StaffApp from '../models/27_staff_app/StaffApp.js';
import ShiftTracking from '../models/27_staff_app/ShiftTracking.js';
import OrgSettings from '../models/28_settings/OrgSettings.js';
import UserPreferences from '../models/28_settings/UserPreferences.js';

const sync = async () => {
  try {
    console.log('🔄 Syncing Phases 26-28...');
    await Promise.all([
      GuestProfile.sync({ alter: true }),
      GuestRequest.sync({ alter: true }),
      StaffApp.sync({ alter: true }),
      ShiftTracking.sync({ alter: true }),
      OrgSettings.sync({ alter: true }),
      UserPreferences.sync({ alter: true })
    ]);
    console.log('✅ Phases 26-28 synced successfully');
  } catch (error) {
    console.error('❌ Sync error:', error.message);
  }
};

sync();
EOF

node backend/src/sync/sync-phases-26-28.js

echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║       ✅ PHASES 26-28: Apps & Settings COMPLETE               ║"
echo "║                                                                ║"
echo "║  Phase 26: Guest Mobile App                                   ║"
echo "║  Phase 27: Staff Apps Suite                                   ║"
echo "║  Phase 28: Settings & Customization                           ║"
echo "║                                                                ║"
echo "║  6 Models | 14 Endpoints | Ready for Upload                   ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""
