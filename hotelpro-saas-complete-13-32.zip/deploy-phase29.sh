#!/bin/bash
set -e
PROJECT_DIR="/workspaces/hotelpro-saas"
cd $PROJECT_DIR

echo "🍕 PHASE 29: Food Delivery Integration"
mkdir -p backend/src/models/29_food_delivery backend/src/routes/29_food_delivery

cat > backend/src/models/29_food_delivery/FoodDeliveryIntegration.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const FoodDeliveryIntegration = sequelize.define('FoodDeliveryIntegration', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false },
  platform: { type: DataTypes.ENUM('zomato', 'swiggy', 'ondc'), defaultValue: 'zomato' },
  merchantId: { type: DataTypes.STRING },
  apiKey: { type: DataTypes.STRING },
  isActive: { type: DataTypes.BOOLEAN, defaultValue: true },
  commissioning: { type: DataTypes.DECIMAL(5, 2), defaultValue: 0 },
  lastSyncTime: { type: DataTypes.DATE }
}, { tableName: 'food_delivery_integrations', timestamps: true });

export default FoodDeliveryIntegration;
EOF

cat > backend/src/models/29_food_delivery/FoodDeliveryOrder.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const FoodDeliveryOrder = sequelize.define('FoodDeliveryOrder', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false },
  orderCode: { type: DataTypes.STRING, unique: true },
  platform: { type: DataTypes.ENUM('zomato', 'swiggy', 'ondc'), defaultValue: 'zomato' },
  externalOrderId: { type: DataTypes.STRING },
  guestName: { type: DataTypes.STRING },
  guestPhone: { type: DataTypes.STRING },
  itemsJson: { type: DataTypes.JSON },
  amount: { type: DataTypes.DECIMAL(10, 2) },
  commission: { type: DataTypes.DECIMAL(10, 2) },
  deliveryCharge: { type: DataTypes.DECIMAL(10, 2) },
  status: { type: DataTypes.ENUM('pending', 'confirmed', 'preparing', 'ready', 'out_for_delivery', 'delivered', 'cancelled'), defaultValue: 'pending' },
  deliveryTime: { type: DataTypes.TIME }
}, { tableName: 'food_delivery_orders', timestamps: true, indexes: [{ fields: ['organizationId', 'status'] }] });

export default FoodDeliveryOrder;
EOF

cat > backend/src/models/29_food_delivery/MenuSync.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const MenuSync = sequelize.define('MenuSync', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false },
  platform: { type: DataTypes.ENUM('zomato', 'swiggy', 'ondc'), defaultValue: 'zomato' },
  lastSyncTime: { type: DataTypes.DATE },
  syncStatus: { type: DataTypes.ENUM('pending', 'syncing', 'completed', 'failed'), defaultValue: 'pending' },
  itemsSynced: { type: DataTypes.INTEGER, defaultValue: 0 },
  errorMessage: { type: DataTypes.TEXT }
}, { tableName: 'menu_sync_logs', timestamps: true });

export default MenuSync;
EOF

cat > backend/src/routes/29_food_delivery/delivery.routes.js << 'EOF'
import express from 'express';
import { authenticate } from '../../middleware/auth.middleware.js';
import FoodDeliveryIntegration from '../../models/29_food_delivery/FoodDeliveryIntegration.js';
import FoodDeliveryOrder from '../../models/29_food_delivery/FoodDeliveryOrder.js';
import MenuSync from '../../models/29_food_delivery/MenuSync.js';

const router = express.Router();
router.use(authenticate);

router.post('/integrations', async (req, res) => {
  try {
    const data = await FoodDeliveryIntegration.create({ organizationId: req.user.organizationId, ...req.body });
    res.status(201).json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.get('/integrations', async (req, res) => {
  try {
    const data = await FoodDeliveryIntegration.findAll({ where: { organizationId: req.user.organizationId } });
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.post('/orders', async (req, res) => {
  try {
    const data = await FoodDeliveryOrder.create({ organizationId: req.user.organizationId, orderCode: `FDO-${Date.now()}`, ...req.body });
    res.status(201).json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.get('/orders', async (req, res) => {
  try {
    const where = { organizationId: req.user.organizationId };
    if (req.query.status) where.status = req.query.status;
    if (req.query.platform) where.platform = req.query.platform;
    const data = await FoodDeliveryOrder.findAll({ where, order: [['createdAt', 'DESC']] });
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.put('/orders/:id/status', async (req, res) => {
  try {
    const order = await FoodDeliveryOrder.findOne({ where: { id: req.params.id, organizationId: req.user.organizationId } });
    if (!order) throw new Error('Order not found');
    const data = await order.update({ status: req.body.status });
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.post('/sync-menu', async (req, res) => {
  try {
    const data = await MenuSync.create({ organizationId: req.user.organizationId, platform: req.body.platform });
    res.status(201).json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

export default router;
EOF

sed -i "/import settingsRoutes/a import deliveryRoutes from './routes/29_food_delivery/delivery.routes.js';" backend/src/server.js
sed -i "/app.use('\/api\/settings'/a app.use('/api/food-delivery', deliveryRoutes);" backend/src/server.js

cat > backend/src/sync/sync-phase29.js << 'EOF'
import FoodDeliveryIntegration from '../models/29_food_delivery/FoodDeliveryIntegration.js';
import FoodDeliveryOrder from '../models/29_food_delivery/FoodDeliveryOrder.js';
import MenuSync from '../models/29_food_delivery/MenuSync.js';

const sync = async () => {
  try {
    console.log('🔄 Syncing Phase 29...');
    await Promise.all([
      FoodDeliveryIntegration.sync({ alter: true }),
      FoodDeliveryOrder.sync({ alter: true }),
      MenuSync.sync({ alter: true })
    ]);
    console.log('✅ Phase 29 synced');
  } catch (error) {
    console.error('❌ Sync error:', error.message);
  }
};

sync();
EOF

node backend/src/sync/sync-phase29.js

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║    ✅ PHASE 29: Food Delivery Integration COMPLETE            ║"
echo "║  Zomato, Swiggy, ONDC | 3 Models | 6 Endpoints               ║"
echo "╚════════════════════════════════════════════════════════════════╝"
