#!/bin/bash
set -e
PROJECT_DIR="/workspaces/hotelpro-saas"
cd $PROJECT_DIR

echo "🎉 PHASE 15: Club Management"
mkdir -p backend/src/models/15_club backend/src/routes/15_club

cat > backend/src/models/15_club/Club.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const Club = sequelize.define('Club', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false, index: true },
  clubName: { type: DataTypes.STRING, allowNull: false },
  clubCode: { type: DataTypes.STRING, unique: true },
  description: { type: DataTypes.TEXT },
  capacity: { type: DataTypes.INTEGER },
  location: { type: DataTypes.STRING },
  timings: { type: DataTypes.JSON },
  coverCharge: { type: DataTypes.DECIMAL(10, 2) },
  isActive: { type: DataTypes.BOOLEAN, defaultValue: true }
}, { tableName: 'clubs', timestamps: true });

export default Club;
EOF

cat > backend/src/models/15_club/ClubMembership.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const ClubMembership = sequelize.define('ClubMembership', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false, index: true },
  memberId: { type: DataTypes.STRING, unique: true },
  guestId: { type: DataTypes.UUID },
  planId: { type: DataTypes.UUID },
  joinDate: { type: DataTypes.DATE },
  renewalDate: { type: DataTypes.DATE },
  status: { type: DataTypes.ENUM('active', 'inactive', 'suspended'), defaultValue: 'active' },
  benefits: { type: DataTypes.JSON }
}, { tableName: 'club_memberships', timestamps: true, indexes: [{ fields: ['organizationId', 'status'] }] });

export default ClubMembership;
EOF

cat > backend/src/models/15_club/ClubEvent.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const ClubEvent = sequelize.define('ClubEvent', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false, index: true },
  eventName: { type: DataTypes.STRING, allowNull: false },
  eventDate: { type: DataTypes.DATE, allowNull: false },
  startTime: { type: DataTypes.TIME },
  endTime: { type: DataTypes.TIME },
  dj: { type: DataTypes.STRING },
  capacity: { type: DataTypes.INTEGER },
  ticketPrice: { type: DataTypes.DECIMAL(10, 2) },
  status: { type: DataTypes.ENUM('planned', 'ongoing', 'completed', 'cancelled'), defaultValue: 'planned' }
}, { tableName: 'club_events', timestamps: true, indexes: [{ fields: ['organizationId', 'eventDate'] }] });

export default ClubEvent;
EOF

cat > backend/src/models/15_club/ClubTable.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const ClubTable = sequelize.define('ClubTable', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false, index: true },
  tableNumber: { type: DataTypes.STRING },
  capacity: { type: DataTypes.INTEGER },
  tableType: { type: DataTypes.ENUM('standard', 'vip', 'premium'), defaultValue: 'standard' },
  chargePerHour: { type: DataTypes.DECIMAL(10, 2) },
  status: { type: DataTypes.ENUM('available', 'reserved', 'occupied'), defaultValue: 'available' }
}, { tableName: 'club_tables', timestamps: true });

export default ClubTable;
EOF

cat > backend/src/routes/15_club/club.service.js << 'EOF'
import Club from '../../models/15_club/Club.js';
import ClubMembership from '../../models/15_club/ClubMembership.js';
import ClubEvent from '../../models/15_club/ClubEvent.js';
import ClubTable from '../../models/15_club/ClubTable.js';

export const createClub = async (organizationId, data) => {
  return await Club.create({ organizationId, clubCode: `CLB-${Date.now()}`, ...data });
};

export const getClubs = async (organizationId) => {
  return await Club.findAll({ where: { organizationId } });
};

export const createMembership = async (organizationId, data) => {
  return await ClubMembership.create({
    organizationId,
    memberId: `MEM-${Date.now()}`,
    ...data
  });
};

export const getMemberships = async (organizationId) => {
  return await ClubMembership.findAll({ where: { organizationId } });
};

export const createEvent = async (organizationId, data) => {
  return await ClubEvent.create({ organizationId, ...data });
};

export const getEvents = async (organizationId, filters = {}) => {
  const where = { organizationId };
  if (filters.status) where.status = filters.status;
  return await ClubEvent.findAll({ where, order: [['eventDate', 'DESC']] });
};

export const createTable = async (organizationId, data) => {
  return await ClubTable.create({ organizationId, ...data });
};

export const getTables = async (organizationId) => {
  return await ClubTable.findAll({ where: { organizationId } });
};
EOF

cat > backend/src/routes/15_club/club.controller.js << 'EOF'
import * as service from './club.service.js';

export const createClub = async (req, res) => {
  try {
    const data = await service.createClub(req.user.organizationId, req.body);
    res.status(201).json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

export const getClubs = async (req, res) => {
  try {
    const data = await service.getClubs(req.user.organizationId);
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

export const createMembership = async (req, res) => {
  try {
    const data = await service.createMembership(req.user.organizationId, req.body);
    res.status(201).json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

export const getMemberships = async (req, res) => {
  try {
    const data = await service.getMemberships(req.user.organizationId);
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

export const createEvent = async (req, res) => {
  try {
    const data = await service.createEvent(req.user.organizationId, req.body);
    res.status(201).json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

export const getEvents = async (req, res) => {
  try {
    const data = await service.getEvents(req.user.organizationId, req.query);
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

export const createTable = async (req, res) => {
  try {
    const data = await service.createTable(req.user.organizationId, req.body);
    res.status(201).json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

export const getTables = async (req, res) => {
  try {
    const data = await service.getTables(req.user.organizationId);
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};
EOF

cat > backend/src/routes/15_club/club.routes.js << 'EOF'
import express from 'express';
import { authenticate } from '../../middleware/auth.middleware.js';
import * as controller from './club.controller.js';

const router = express.Router();
router.use(authenticate);

router.post('/', controller.createClub);
router.get('/', controller.getClubs);
router.post('/memberships', controller.createMembership);
router.get('/memberships', controller.getMemberships);
router.post('/events', controller.createEvent);
router.get('/events', controller.getEvents);
router.post('/tables', controller.createTable);
router.get('/tables', controller.getTables);

export default router;
EOF

sed -i "/import integrationsRoutes/a import clubRoutes from './routes/15_club/club.routes.js';" backend/src/server.js
sed -i "/app.use('\/api\/integrations'/a app.use('/api/club', clubRoutes);" backend/src/server.js

cat > backend/src/sync/sync-phase15.js << 'EOF'
import sequelize from '../config/database.js';
import Club from '../models/15_club/Club.js';
import ClubMembership from '../models/15_club/ClubMembership.js';
import ClubEvent from '../models/15_club/ClubEvent.js';
import ClubTable from '../models/15_club/ClubTable.js';

const sync = async () => {
  try {
    console.log('🔄 Syncing Phase 15...');
    await Promise.all([
      Club.sync({ alter: true }),
      ClubMembership.sync({ alter: true }),
      ClubEvent.sync({ alter: true }),
      ClubTable.sync({ alter: true })
    ]);
    console.log('✅ Phase 15 synced');
  } catch (error) {
    console.error('❌ Sync error:', error.message);
  }
};

sync();
EOF

node backend/src/sync/sync-phase15.js

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║           ✅ PHASE 15: Club Management COMPLETE                ║"
echo "║        4 Models | 8 Endpoints | Ready for Upload              ║"
echo "╚════════════════════════════════════════════════════════════════╝"
