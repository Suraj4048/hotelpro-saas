#!/bin/bash
set -e
PROJECT_DIR="/workspaces/hotelpro-saas"
cd $PROJECT_DIR

echo "🏢 PHASE 31: Multi-property Architecture"
mkdir -p backend/src/models/31_property backend/src/routes/31_property

cat > backend/src/models/31_property/Property.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const Property = sequelize.define('Property', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false },
  propertyCode: { type: DataTypes.STRING, unique: true },
  propertyName: { type: DataTypes.STRING, allowNull: false },
  propertyType: { type: DataTypes.ENUM('hotel', 'resort', 'boutique', 'villa', 'inn'), defaultValue: 'hotel' },
  address: { type: DataTypes.TEXT },
  city: { type: DataTypes.STRING },
  state: { type: DataTypes.STRING },
  pincode: { type: DataTypes.STRING },
  country: { type: DataTypes.STRING },
  latitude: { type: DataTypes.DECIMAL(9, 6) },
  longitude: { type: DataTypes.DECIMAL(9, 6) },
  contactPerson: { type: DataTypes.STRING },
  contactEmail: { type: DataTypes.STRING },
  contactPhone: { type: DataTypes.STRING },
  totalRooms: { type: DataTypes.INTEGER },
  isActive: { type: DataTypes.BOOLEAN, defaultValue: true }
}, { tableName: 'properties', timestamps: true, indexes: [{ fields: ['organizationId', 'city'] }] });

export default Property;
EOF

cat > backend/src/models/31_property/PropertySettings.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const PropertySettings = sequelize.define('PropertySettings', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  propertyId: { type: DataTypes.UUID },
  organizationId: { type: DataTypes.UUID, allowNull: false },
  checkInTime: { type: DataTypes.TIME, defaultValue: '14:00' },
  checkOutTime: { type: DataTypes.TIME, defaultValue: '12:00' },
  timezone: { type: DataTypes.STRING, defaultValue: 'Asia/Kolkata' },
  currency: { type: DataTypes.STRING, defaultValue: 'INR' },
  cancellationPolicy: { type: DataTypes.TEXT },
  gstNumber: { type: DataTypes.STRING },
  fssaiNumber: { type: DataTypes.STRING },
  licenseDetails: { type: DataTypes.JSON }
}, { tableName: 'property_settings', timestamps: true });

export default PropertySettings;
EOF

cat > backend/src/models/31_property/PropertyUser.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const PropertyUser = sequelize.define('PropertyUser', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false },
  propertyId: { type: DataTypes.UUID },
  userId: { type: DataTypes.UUID },
  role: { type: DataTypes.ENUM('manager', 'assistant', 'staff', 'viewer'), defaultValue: 'staff' },
  permissions: { type: DataTypes.JSON },
  isActive: { type: DataTypes.BOOLEAN, defaultValue: true }
}, { tableName: 'property_users', timestamps: true });

export default PropertyUser;
EOF

cat > backend/src/models/31_property/PropertyMetrics.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const PropertyMetrics = sequelize.define('PropertyMetrics', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false },
  propertyId: { type: DataTypes.UUID },
  date: { type: DataTypes.DATE },
  occupancy: { type: DataTypes.DECIMAL(5, 2) },
  revenue: { type: DataTypes.DECIMAL(12, 2) },
  avgNightlyRate: { type: DataTypes.DECIMAL(10, 2) },
  totalGuests: { type: DataTypes.INTEGER },
  totalBookings: { type: DataTypes.INTEGER }
}, { tableName: 'property_metrics', timestamps: true, indexes: [{ fields: ['organizationId', 'propertyId', 'date'] }] });

export default PropertyMetrics;
EOF

cat > backend/src/routes/31_property/property.routes.js << 'EOF'
import express from 'express';
import { authenticate } from '../../middleware/auth.middleware.js';
import Property from '../../models/31_property/Property.js';
import PropertySettings from '../../models/31_property/PropertySettings.js';
import PropertyUser from '../../models/31_property/PropertyUser.js';
import PropertyMetrics from '../../models/31_property/PropertyMetrics.js';

const router = express.Router();
router.use(authenticate);

router.post('/', async (req, res) => {
  try {
    const data = await Property.create({ organizationId: req.user.organizationId, propertyCode: `PROP-${Date.now()}`, ...req.body });
    res.status(201).json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.get('/', async (req, res) => {
  try {
    const data = await Property.findAll({ where: { organizationId: req.user.organizationId } });
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const property = await Property.findOne({ where: { id: req.params.id, organizationId: req.user.organizationId } });
    if (!property) throw new Error('Property not found');
    const data = await property.update(req.body);
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.post('/:propertyId/settings', async (req, res) => {
  try {
    const data = await PropertySettings.create({ organizationId: req.user.organizationId, propertyId: req.params.propertyId, ...req.body });
    res.status(201).json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.get('/:propertyId/settings', async (req, res) => {
  try {
    const data = await PropertySettings.findOne({ where: { organizationId: req.user.organizationId, propertyId: req.params.propertyId } });
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.post('/:propertyId/users', async (req, res) => {
  try {
    const data = await PropertyUser.create({ organizationId: req.user.organizationId, propertyId: req.params.propertyId, ...req.body });
    res.status(201).json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.get('/:propertyId/metrics', async (req, res) => {
  try {
    const data = await PropertyMetrics.findAll({ where: { organizationId: req.user.organizationId, propertyId: req.params.propertyId }, order: [['date', 'DESC']] });
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

export default router;
EOF

sed -i "/import otaRoutes/a import propertyRoutes from './routes/31_property/property.routes.js';" backend/src/server.js
sed -i "/app.use('\/api\/ota'/a app.use('/api/properties', propertyRoutes);" backend/src/server.js

cat > backend/src/sync/sync-phase31.js << 'EOF'
import Property from '../models/31_property/Property.js';
import PropertySettings from '../models/31_property/PropertySettings.js';
import PropertyUser from '../models/31_property/PropertyUser.js';
import PropertyMetrics from '../models/31_property/PropertyMetrics.js';

const sync = async () => {
  try {
    console.log('🔄 Syncing Phase 31...');
    await Promise.all([
      Property.sync({ alter: true }),
      PropertySettings.sync({ alter: true }),
      PropertyUser.sync({ alter: true }),
      PropertyMetrics.sync({ alter: true })
    ]);
    console.log('✅ Phase 31 synced');
  } catch (error) {
    console.error('❌ Sync error:', error.message);
  }
};

sync();
EOF

node backend/src/sync/sync-phase31.js

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║  ✅ PHASE 31: Multi-property Architecture COMPLETE            ║"
echo "║  Properties, Settings, Users, Metrics | 4 Models | 7 Endpoints║"
echo "╚════════════════════════════════════════════════════════════════╝"
