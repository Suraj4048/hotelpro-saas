#!/bin/bash
set -e
PROJECT_DIR="/workspaces/hotelpro-saas"
cd $PROJECT_DIR

echo "⚡ PHASE 32: Command Palette & Advanced UI"
mkdir -p backend/src/models/32_ui backend/src/routes/32_ui

cat > backend/src/models/32_ui/CommandPalette.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const CommandPalette = sequelize.define('CommandPalette', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false },
  commandId: { type: DataTypes.STRING, unique: true },
  commandName: { type: DataTypes.STRING },
  description: { type: DataTypes.TEXT },
  category: { type: DataTypes.STRING },
  shortcut: { type: DataTypes.STRING },
  action: { type: DataTypes.STRING },
  icon: { type: DataTypes.STRING },
  isActive: { type: DataTypes.BOOLEAN, defaultValue: true }
}, { tableName: 'command_palette', timestamps: true, indexes: [{ fields: ['organizationId', 'category'] }] });

export default CommandPalette;
EOF

cat > backend/src/models/32_ui/UserShortcut.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const UserShortcut = sequelize.define('UserShortcut', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false },
  userId: { type: DataTypes.UUID },
  commandId: { type: DataTypes.UUID },
  customShortcut: { type: DataTypes.STRING },
  isFavorite: { type: DataTypes.BOOLEAN, defaultValue: false }
}, { tableName: 'user_shortcuts', timestamps: true });

export default UserShortcut;
EOF

cat > backend/src/models/32_ui/Dashboard.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const Dashboard = sequelize.define('Dashboard', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false },
  userId: { type: DataTypes.UUID },
  dashboardName: { type: DataTypes.STRING },
  dashboardType: { type: DataTypes.ENUM('default', 'custom'), defaultValue: 'custom' },
  widgets: { type: DataTypes.JSON },
  layout: { type: DataTypes.JSON },
  isDefault: { type: DataTypes.BOOLEAN, defaultValue: false }
}, { tableName: 'dashboards', timestamps: true });

export default Dashboard;
EOF

cat > backend/src/models/32_ui/UITheme.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const UITheme = sequelize.define('UITheme', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false },
  userId: { type: DataTypes.UUID },
  theme: { type: DataTypes.ENUM('light', 'dark', 'auto'), defaultValue: 'auto' },
  primaryColor: { type: DataTypes.STRING },
  accentColor: { type: DataTypes.STRING },
  fontSize: { type: DataTypes.ENUM('small', 'medium', 'large'), defaultValue: 'medium' },
  sidebarCollapsed: { type: DataTypes.BOOLEAN, defaultValue: false }
}, { tableName: 'ui_themes', timestamps: true });

export default UITheme;
EOF

cat > backend/src/routes/32_ui/ui.routes.js << 'EOF'
import express from 'express';
import { authenticate } from '../../middleware/auth.middleware.js';
import CommandPalette from '../../models/32_ui/CommandPalette.js';
import UserShortcut from '../../models/32_ui/UserShortcut.js';
import Dashboard from '../../models/32_ui/Dashboard.js';
import UITheme from '../../models/32_ui/UITheme.js';

const router = express.Router();
router.use(authenticate);

router.get('/commands', async (req, res) => {
  try {
    const data = await CommandPalette.findAll({ where: { organizationId: req.user.organizationId } });
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.post('/shortcuts', async (req, res) => {
  try {
    const data = await UserShortcut.create({ organizationId: req.user.organizationId, userId: req.user.id, ...req.body });
    res.status(201).json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.get('/shortcuts', async (req, res) => {
  try {
    const data = await UserShortcut.findAll({ where: { organizationId: req.user.organizationId, userId: req.user.id } });
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.post('/dashboards', async (req, res) => {
  try {
    const data = await Dashboard.create({ organizationId: req.user.organizationId, userId: req.user.id, ...req.body });
    res.status(201).json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.get('/dashboards', async (req, res) => {
  try {
    const data = await Dashboard.findAll({ where: { organizationId: req.user.organizationId, userId: req.user.id } });
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.put('/dashboards/:id', async (req, res) => {
  try {
    const dashboard = await Dashboard.findOne({ where: { id: req.params.id, organizationId: req.user.organizationId } });
    if (!dashboard) throw new Error('Dashboard not found');
    const data = await dashboard.update(req.body);
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.get('/theme', async (req, res) => {
  try {
    const data = await UITheme.findOne({ where: { organizationId: req.user.organizationId, userId: req.user.id } });
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

router.put('/theme', async (req, res) => {
  try {
    let theme = await UITheme.findOne({ where: { organizationId: req.user.organizationId, userId: req.user.id } });
    if (!theme) {
      theme = await UITheme.create({ organizationId: req.user.organizationId, userId: req.user.id, ...req.body });
    } else {
      await theme.update(req.body);
    }
    res.json({ success: true, data: theme });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

export default router;
EOF

sed -i "/import propertyRoutes/a import uiRoutes from './routes/32_ui/ui.routes.js';" backend/src/server.js
sed -i "/app.use('\/api\/properties'/a app.use('/api/ui', uiRoutes);" backend/src/server.js

cat > backend/src/sync/sync-phase32.js << 'EOF'
import CommandPalette from '../models/32_ui/CommandPalette.js';
import UserShortcut from '../models/32_ui/UserShortcut.js';
import Dashboard from '../models/32_ui/Dashboard.js';
import UITheme from '../models/32_ui/UITheme.js';

const sync = async () => {
  try {
    console.log('🔄 Syncing Phase 32...');
    await Promise.all([
      CommandPalette.sync({ alter: true }),
      UserShortcut.sync({ alter: true }),
      Dashboard.sync({ alter: true }),
      UITheme.sync({ alter: true })
    ]);
    console.log('✅ Phase 32 synced');
  } catch (error) {
    console.error('❌ Sync error:', error.message);
  }
};

sync();
EOF

node backend/src/sync/sync-phase32.js

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║    ✅ PHASE 32: Command Palette & UI COMPLETE                 ║"
echo "║  Commands, Shortcuts, Dashboards, Themes | 4 Models | 8 Endpoints║"
echo "╚════════════════════════════════════════════════════════════════╝"
