#!/bin/bash
set -e
PROJECT_DIR="/workspaces/hotelpro-saas"
cd $PROJECT_DIR

echo "🎊 PHASE 16: Kitty & Party Hall"
mkdir -p backend/src/models/16_kitty backend/src/routes/16_kitty

cat > backend/src/models/16_kitty/KittyGroup.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const KittyGroup = sequelize.define('KittyGroup', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false, index: true },
  groupName: { type: DataTypes.STRING, allowNull: false },
  groupCode: { type: DataTypes.STRING, unique: true },
  groupLeader: { type: DataTypes.STRING },
  memberCount: { type: DataTypes.INTEGER },
  monthlyAmount: { type: DataTypes.DECIMAL(10, 2) },
  frequency: { type: DataTypes.ENUM('monthly', 'quarterly', 'yearly'), defaultValue: 'monthly' },
  status: { type: DataTypes.ENUM('active', 'inactive'), defaultValue: 'active' }
}, { tableName: 'kitty_groups', timestamps: true });

export default KittyGroup;
EOF

cat > backend/src/models/16_kitty/KittyEvent.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const KittyEvent = sequelize.define('KittyEvent', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false, index: true },
  groupId: { type: DataTypes.UUID },
  eventName: { type: DataTypes.STRING, allowNull: false },
  eventDate: { type: DataTypes.DATE },
  theme: { type: DataTypes.STRING },
  guestCount: { type: DataTypes.INTEGER },
  expectedAmount: { type: DataTypes.DECIMAL(12, 2) },
  actualAmount: { type: DataTypes.DECIMAL(12, 2) },
  status: { type: DataTypes.ENUM('planned', 'completed', 'cancelled'), defaultValue: 'planned' }
}, { tableName: 'kitty_events', timestamps: true, indexes: [{ fields: ['organizationId', 'eventDate'] }] });

export default KittyEvent;
EOF

cat > backend/src/models/16_kitty/PartyHall.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const PartyHall = sequelize.define('PartyHall', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false, index: true },
  hallName: { type: DataTypes.STRING, allowNull: false },
  capacity: { type: DataTypes.INTEGER },
  hallType: { type: DataTypes.ENUM('indoor', 'outdoor', 'combined'), defaultValue: 'indoor' },
  ratePerHour: { type: DataTypes.DECIMAL(10, 2) },
  amenities: { type: DataTypes.JSON },
  photos: { type: DataTypes.JSON }
}, { tableName: 'party_halls', timestamps: true });

export default PartyHall;
EOF

cat > backend/src/models/16_kitty/PartyHallBooking.js << 'EOF'
import { DataTypes } from 'sequelize';
import sequelize from '../../config/database.js';

const PartyHallBooking = sequelize.define('PartyHallBooking', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  organizationId: { type: DataTypes.UUID, allowNull: false, index: true },
  bookingCode: { type: DataTypes.STRING, unique: true },
  hallId: { type: DataTypes.UUID },
  groupId: { type: DataTypes.UUID },
  bookingDate: { type: DataTypes.DATE },
  eventDate: { type: DataTypes.DATE },
  startTime: { type: DataTypes.TIME },
  endTime: { type: DataTypes.TIME },
  hours: { type: DataTypes.INTEGER },
  rate: { type: DataTypes.DECIMAL(10, 2) },
  totalAmount: { type: DataTypes.DECIMAL(12, 2) },
  advance: { type: DataTypes.DECIMAL(12, 2) },
  status: { type: DataTypes.ENUM('booked', 'confirmed', 'completed', 'cancelled'), defaultValue: 'booked' }
}, { tableName: 'party_hall_bookings', timestamps: true, indexes: [{ fields: ['organizationId', 'eventDate'] }] });

export default PartyHallBooking;
EOF

cat > backend/src/routes/16_kitty/kitty.service.js << 'EOF'
import KittyGroup from '../../models/16_kitty/KittyGroup.js';
import KittyEvent from '../../models/16_kitty/KittyEvent.js';
import PartyHall from '../../models/16_kitty/PartyHall.js';
import PartyHallBooking from '../../models/16_kitty/PartyHallBooking.js';

export const createGroup = async (organizationId, data) => {
  return await KittyGroup.create({
    organizationId,
    groupCode: `KTY-${Date.now()}`,
    ...data
  });
};

export const getGroups = async (organizationId) => {
  return await KittyGroup.findAll({ where: { organizationId } });
};

export const createEvent = async (organizationId, data) => {
  return await KittyEvent.create({ organizationId, ...data });
};

export const getEvents = async (organizationId) => {
  return await KittyEvent.findAll({ where: { organizationId }, order: [['eventDate', 'DESC']] });
};

export const createHall = async (organizationId, data) => {
  return await PartyHall.create({ organizationId, ...data });
};

export const getHalls = async (organizationId) => {
  return await PartyHall.findAll({ where: { organizationId } });
};

export const bookHall = async (organizationId, data) => {
  return await PartyHallBooking.create({
    organizationId,
    bookingCode: `BK-${Date.now()}`,
    ...data
  });
};

export const getBookings = async (organizationId) => {
  return await PartyHallBooking.findAll({ where: { organizationId }, order: [['eventDate', 'DESC']] });
};
EOF

cat > backend/src/routes/16_kitty/kitty.controller.js << 'EOF'
import * as service from './kitty.service.js';

export const createGroup = async (req, res) => {
  try {
    const data = await service.createGroup(req.user.organizationId, req.body);
    res.status(201).json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

export const getGroups = async (req, res) => {
  try {
    const data = await service.getGroups(req.user.organizationId);
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

export const createEvent = async (req, res) => {
  try {
    const data = await service.createEvent(req.user.organizationId, req.body);
    res.status(201).json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

export const getEvents = async (req, res) => {
  try {
    const data = await service.getEvents(req.user.organizationId);
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

export const createHall = async (req, res) => {
  try {
    const data = await service.createHall(req.user.organizationId, req.body);
    res.status(201).json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

export const getHalls = async (req, res) => {
  try {
    const data = await service.getHalls(req.user.organizationId);
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

export const bookHall = async (req, res) => {
  try {
    const data = await service.bookHall(req.user.organizationId, req.body);
    res.status(201).json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

export const getBookings = async (req, res) => {
  try {
    const data = await service.getBookings(req.user.organizationId);
    res.json({ success: true, data });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};
EOF

cat > backend/src/routes/16_kitty/kitty.routes.js << 'EOF'
import express from 'express';
import { authenticate } from '../../middleware/auth.middleware.js';
import * as controller from './kitty.controller.js';

const router = express.Router();
router.use(authenticate);

router.post('/groups', controller.createGroup);
router.get('/groups', controller.getGroups);
router.post('/events', controller.createEvent);
router.get('/events', controller.getEvents);
router.post('/halls', controller.createHall);
router.get('/halls', controller.getHalls);
router.post('/bookings', controller.bookHall);
router.get('/bookings', controller.getBookings);

export default router;
EOF

sed -i "/import clubRoutes/a import kittyRoutes from './routes/16_kitty/kitty.routes.js';" backend/src/server.js
sed -i "/app.use('\/api\/club'/a app.use('/api/kitty', kittyRoutes);" backend/src/server.js

cat > backend/src/sync/sync-phase16.js << 'EOF'
import sequelize from '../config/database.js';
import KittyGroup from '../models/16_kitty/KittyGroup.js';
import KittyEvent from '../models/16_kitty/KittyEvent.js';
import PartyHall from '../models/16_kitty/PartyHall.js';
import PartyHallBooking from '../models/16_kitty/PartyHallBooking.js';

const sync = async () => {
  try {
    console.log('🔄 Syncing Phase 16...');
    await Promise.all([
      KittyGroup.sync({ alter: true }),
      KittyEvent.sync({ alter: true }),
      PartyHall.sync({ alter: true }),
      PartyHallBooking.sync({ alter: true })
    ]);
    console.log('✅ Phase 16 synced');
  } catch (error) {
    console.error('❌ Sync error:', error.message);
  }
};

sync();
EOF

node backend/src/sync/sync-phase16.js

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║      ✅ PHASE 16: Kitty & Party Hall COMPLETE                 ║"
echo "║        4 Models | 8 Endpoints | Ready for Upload              ║"
echo "╚════════════════════════════════════════════════════════════════╝"
